# %% [markdown]
# # 卷积循环神经网络模块(ConvRNN)

# %%
import paddle
import paddle.nn as nn


# %% [markdown]
# ## ConvLSTMCell

# %%
"""
Created on Mon September 06 09:16:36 2021
ConvLSTMCell
@author: BEOH
"""

class ConvLSTMCell(nn.Layer):
    """参数:
        ConvLSTM Cell
        - input_size: int
            输入通道数
        - hidden_size: int
            隐含层通道数
        - kernel_size: int or (int, int)
            卷积核大小
        - bias: bool
            是否添加偏置
        - padding: (int, int)
            None:根据卷积核计算得到
        - act: 激活函数
        - dropout_rate: 丢弃率
    """

    def __init__(self,
                 input_size,
                 hidden_size,
                 kernel_size,
                 bias=True,
                 padding=None,
                 act=nn.Sigmoid()):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.kernel_size = kernel_size
        self.bias = None if bias == True else bias  # 与torch不同之处
        if padding is None:
            self.padding = kernel_size//2 if isinstance(
                kernel_size, int) else (kernel_size[0]//2, kernel_size[1]//2)
        else:
            self.padding = padding
        self.act = act
        self.conv2d = nn.Conv2D(self.input_size+self.hidden_size,
                                4*self.hidden_size,
                                self.kernel_size,
                                padding=self.padding,
                                bias_attr=self.bias)
        self.tanh = nn.Tanh()

    def forward(self, inputs, hc_state):
        h_state, c_state = hc_state
        xh = paddle.concat([inputs, h_state], axis=1)
        xh_conv = self.conv2d(xh)
        cc_f, cc_i, cc_c, cc_o = paddle.split(xh_conv, 4,  axis=1)
        cell_f = self.act(cc_f)
        cell_i = self.act(cc_i)
        cell_c = self.tanh(cc_c)
        cell_o = self.act(cc_o)
        c_next = cell_f*c_state+cell_i*cell_c
        h_next = cell_o*self.tanh(c_next)

        return h_next, c_next


# %% [markdown]
# ## ConvLSTM

# %%
"""
Created on Mon September 06 09:16:36 2021
ConvLSTMCell -> ConvLSTM
@author: BEOH
"""


class ConvLSTM(nn.Layer):
    """
    参数:
        - input_size: int
            输入通道数
        - hidden_size: list
            隐含层通道数列表
        - kernel_size: list
            卷积核大小列表
        - num_layers: int
            层数
        - batch_first: bool
            第一列是否为batchsize
        - bias: bool
            卷积运算是否使用偏置
        - return_all_layers: bool
            是否输出所有层的结果
        - act: 
            激活函数, 默认None-sigmoid激活函数; 'relu': relu激活函数
        - dropout_rate: 丢弃率

    输入:
        - (B, T, C, H, W) or (T, B, C, H, W)

    输出:
        - 所有层h的列表, 每层最后(h, c)的列表

    例子:
        >> a = paddle.randn((7, 3, 5, 8, 8))

        >> mm = ConvLSTM(5, [10, 15], [(3, 3), (5, 5)], 2, dropout_rate = 0.2)

        >> b = mm(a)

        >> print(b)
    """

    def __init__(self,
                 input_size,
                 hidden_size,
                 kernel_size,
                 num_layers,
                 batch_first=True,
                 bias=True,
                 return_all_layers=False,
                 act=None,
                 dropout_rate: float = 0.0):
        super().__init__()
        self._check_kernel_size_consistency(kernel_size)
        # 保证卷积核和隐含层通道数的长度相同
        kernel_size = self._extend_for_multilayer(kernel_size, num_layers)
        hidden_size = self._extend_for_multilayer(hidden_size, num_layers)
        if not len(kernel_size) == len(hidden_size) == num_layers:
            raise ValueError('列表长度不一致（卷积核、隐含层、层数）')

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.kernel_size = kernel_size
        self.num_layers = num_layers
        self.batch_first = batch_first
        self.bias = bias
        self.dropout_rate = dropout_rate
        self.return_all_layers = return_all_layers
        if act == None:
            self.act = nn.Sigmoid()
        elif act == 'relu':
            self.act = nn.ReLU()
        else:
            raise ValueError("激活函数有误, 请指定act=None or 'relu'")
        self.dropout_rate = dropout_rate

        cell_list = []
        for i in range(self.num_layers):
            current_input_size = self.hidden_size[i -
                                                1] if i != 0 else self.input_size
            cell_list.append(ConvLSTMCell(current_input_size,
                                          self.hidden_size[i],
                                          self.kernel_size[i],
                                          bias=self.bias,
                                          act=self.act))
        self.cell_list = nn.LayerList(cell_list)
        self.dropout2d = nn.Dropout2D(self.dropout_rate)

    def forward(self, inputs, hidden_state=None):
        if not self.batch_first:
            # (t, b, c, h, w) -> (b, t, c, h, w)
            inputs = paddle.transpose(inputs, [1, 0, 2, 3, 4])
        x = inputs
        batch_size, seq, _, H, W = x.shape
        if hidden_state is not None:
            raise NotImplementedError()
        else:
            init_hidden_states = self._init_hidden_state(batch_size, H, W)

        outputs_list = []
        last_state_list = []
        for layer_idx in range(self.num_layers):
            output = []
            current_h, current_c = init_hidden_states[layer_idx]
            for t in range(seq):
                x_t = x[:, t, :, :, :]
                if layer_idx != 0 and self.dropout_rate != 0.0:
                    x_t = self.dropout2d(x_t)
                current_h, current_c = self.cell_list[layer_idx](
                    x_t, (current_h, current_c))
                output.append(current_h)

            outputs = paddle.stack(output, axis=1)
            outputs_list.append(outputs)
            last_state_list.append((current_h, current_c))
            x = outputs

        if not self.return_all_layers:
            outputs_list = outputs_list[-1]
            last_state_list = last_state_list[-1]

        return outputs_list, last_state_list

    def _init_hidden_state(self, batch_size, h, w):
        init_hidden_states = []
        for i in range(self.num_layers):
            init_hidden_states.append((paddle.zeros((batch_size, self.hidden_size[i], h, w)),
                                       paddle.zeros((batch_size, self.hidden_size[i], h, w))))
        return init_hidden_states

    @staticmethod
    def _check_kernel_size_consistency(kernel_size):
        if not (isinstance(kernel_size, int) or
                isinstance(kernel_size, tuple) or
                (isinstance(kernel_size, list) and all([isinstance(x, tuple) for x in kernel_size]))):
            raise ValueError('`kernel_size`必须是int、tuple或者tuple的list。')

    @staticmethod
    def _extend_for_multilayer(in_in, num_layers):
        if not isinstance(in_in, list):
            in_in = [in_in] * num_layers
        return in_in


# %% [markdown]
# ## ConvGRUCell

# %%
"""
Created on Mon September 06 09:16:36 2021
ConvGRUCell
@author: BEOH
"""

class ConvGRUCell(nn.Layer):
    """参数:
        ConvGRU Cell
        - input_size: int
            输入通道数
        - hidden_size: int
            隐含层通道数
        - kernel_size: int or (int, int)
            卷积核大小
        - bias: bool
            是否添加偏置
        - padding: (int, int)
            None:根据卷积核计算得到
        - act: 激活函数
        - dropout_rate: 丢弃率
    """

    def __init__(self,
                 input_size,
                 hidden_size,
                 kernel_size,
                 bias=True,
                 padding=None,
                 act=nn.Sigmoid()):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.kernel_size = kernel_size
        self.bias = None if bias == True else bias  # 与torch不同之处
        if padding is None:
            self.padding = kernel_size//2 if isinstance(
                kernel_size, int) else (kernel_size[0]//2, kernel_size[1]//2)
        else:
            self.padding = padding
        self.act = act
        self.tanh = nn.Tanh()

        self.convRZ = nn.Conv2D(in_channels=self.input_size+self.hidden_size,
                                out_channels=2*self.hidden_size,
                                kernel_size=self.kernel_size,
                                padding=self.padding,
                                bias_attr=self.bias)
        self.convXRH = nn.Conv2D(in_channels=self.input_size+self.hidden_size,
                                 out_channels=self.hidden_size,
                                 kernel_size=self.kernel_size,
                                 padding=self.padding,
                                 bias_attr=self.bias)

    def forward(self, inputs, h_state):
        xh = paddle.concat([inputs, h_state], axis=1)
        xh_conv = self.convRZ(xh)
        cc_r, cc_z = paddle.split(xh_conv, 2, axis=1)
        cell_r = self.act(cc_r)
        cell_z = self.act(cc_z)
        cell_rh = cell_r*h_state
        cell_xrh = self.convXRH(paddle.concat([inputs, cell_rh], axis=1))
        cell_h = self.tanh(cell_xrh)
        h_next = (1.0-cell_z)*h_state+cell_z*cell_h
        return h_next


# %% [markdown]
# ## ConvGRU

# %%
"""
Created on Mon September 06 09:16:36 2021
ConvGRUCell -> ConvGRU
@author: BEOH
"""


class ConvGRU(nn.Layer):
    """
    参数:
        - input_size: int
            输入通道数
        - hidden_size: list
            隐含层通道数列表
        - kernel_size: list
            卷积核大小列表
        - num_layers: int
            层数
        - batch_first: bool
            第一列是否为batchsize
        - bias: bool
            卷积运算是否使用偏置
        - return_all_layers: bool
            是否输出所有层的结果
        - act: 
            激活函数, 默认None-sigmoid激活函数; 'relu': relu激活函数
        - dropout_rate: 丢弃率

    输入:
        - (B, T, C, H, W) or (T, B, C, H, W)

    输出:
        - 所有层h的列表, 每层最后(h, c)的列表

    例子:
        >> a = paddle.randn((7, 3, 5, 8, 8))

        >> mm = ConvGRU(5, [10, 15], [(3, 3), (5, 5)], 2, dropout_rate = 0.2)

        >> b = mm(a)

        >> print(b)
    """

    def __init__(self,
                 input_size,
                 hidden_size,
                 kernel_size,
                 num_layers=1,
                 batch_first=True,
                 bias=True,
                 return_all_layers=False,
                 act=None,
                 dropout_rate: float = 0.0):
        super().__init__()
        self._check_kernel_size_consistency(kernel_size)
        # 保证卷积核和隐含层通道数的长度相同
        kernel_size = self._extend_for_multilayer(kernel_size, num_layers)
        hidden_size = self._extend_for_multilayer(hidden_size, num_layers)
        if not len(kernel_size) == len(hidden_size) == num_layers:
            raise ValueError('列表长度不一致（卷积核、隐含层、层数）')

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.kernel_size = kernel_size
        self.num_layers = num_layers
        self.batch_first = batch_first
        self.bias = bias
        self.dropout_rate = dropout_rate
        self.return_all_layers = return_all_layers
        if act == None:
            self.act = nn.Sigmoid()
        elif act == 'relu':
            self.act = nn.ReLU()
        else:
            raise ValueError("激活函数有误, 请指定act=None or 'relu'")
        self.dropout_rate = dropout_rate

        cell_list = []
        for i in range(self.num_layers):
            current_input_size = self.hidden_size[i -
                                                1] if i != 0 else self.input_size
            cell_list.append(ConvGRUCell(current_input_size,
                                         self.hidden_size[i],
                                         self.kernel_size[i],
                                         bias=self.bias,
                                         act=self.act))
        self.cell_list = nn.LayerList(cell_list)
        self.dropout2d = nn.Dropout2D(self.dropout_rate)

    def forward(self, inputs, hidden_state=None):
        if not self.batch_first:
            # (t, b, c, h, w) -> (b, t, c, h, w)
            inputs = paddle.transpose(inputs, [1, 0, 2, 3, 4])
        x = inputs
        batch_size, seq, _, H, W = x.shape
        if hidden_state is not None:
            raise NotImplementedError()
        else:
            init_hidden_states = self._init_hidden_state(batch_size, H, W)

        outputs_list = []
        last_state_list = []
        for layer_idx in range(self.num_layers):
            output = []
            current_h = init_hidden_states[layer_idx]
            for t in range(seq):
                x_t = x[:, t, :, :, :]
                if layer_idx != 0 and self.dropout_rate != 0.0:
                    x_t = self.dropout2d(x_t)
                current_h = self.cell_list[layer_idx](x_t, current_h)
                output.append(current_h)
            outputs = paddle.stack(output, axis=1)
            outputs_list.append(outputs)
            last_state_list.append(current_h)
            x = outputs

        if not self.return_all_layers:
            outputs_list = outputs_list[-1]
            last_state_list = last_state_list[-1]

        return outputs_list, last_state_list

    def _init_hidden_state(self, batch_size, h, w):
        init_hidden_states = []
        for i in range(self.num_layers):
            init_hidden_states.append(paddle.zeros(
                (batch_size, self.hidden_size[i], h, w)))
        return init_hidden_states

    @staticmethod
    def _check_kernel_size_consistency(kernel_size):
        if not (isinstance(kernel_size, int) or
                isinstance(kernel_size, tuple) or
                (isinstance(kernel_size, list) and all([isinstance(x, tuple) for x in kernel_size]))):
            raise ValueError('`kernel_size`必须是int、tuple或者tuple的list。')

    @staticmethod
    def _extend_for_multilayer(in_in, num_layers):
        if not isinstance(in_in, list):
            in_in = [in_in] * num_layers
        return in_in


# %% [markdown]
# ## End

# %%



