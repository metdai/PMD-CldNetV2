# %% [markdown]
# # 自注意力机制(Attention)

# %%
import paddle
import paddle.nn as nn


# %% [markdown]
# ## Attention1d

# %%
"""
Created on Mon September 06 09:16:36 2021
Attention1d
@author: BEOH
"""


class Attention1d(nn.Layer):
    """参数:
        Attention1d
        - in_size: int
            输入通道数
        - qk_size: int
            qk通道数
        - out_size: int
            输出通道数
        - bias: bool
            是否添加偏置\n
        example:
        - inputs: (N, L, in_size)
        - outputs: (N, L, out_size)
    """

    def __init__(self,
                 in_size,
                 qk_size,
                 out_size,
                 bias=True):
        super().__init__()
        self.in_size = in_size
        self.qk_size = qk_size
        self.out_size = out_size
        self.bias = bias
        self.q_proj = nn.Linear(self.in_size, self.qk_size, bias_attr=self.bias)
        self.k_proj = nn.Linear(self.in_size, self.qk_size, bias_attr=self.bias)
        self.v_proj = nn.Linear(self.in_size, self.out_size, bias_attr=self.bias)
        self.softmax = nn.Softmax(axis=-1)
        self.norm_factor = 1.0/(self.qk_size**0.5)

    def forward(self, inputs):
        Q = self.q_proj(inputs)
        K = self.k_proj(inputs)
        V = self.v_proj(inputs)

        QK = paddle.bmm(Q, K.transpose(perm=[0, 2, 1]))*self.norm_factor
        QK = self.softmax(QK)
        outputs = paddle.bmm(QK, V)

        return outputs


# %% [markdown]
# ## Attention2d

# %%
"""
Created on Mon September 06 09:16:36 2021
Attention2d
@author: BEOH
"""


class Attention2d(nn.Layer):
    """参数:
        Attention2d
        - in_size: int
            输入通道数
        - out_size: int
            输出通道数
        - kernel_size: int or (int, int)
            卷积核大小
        - bias: bool
            是否添加偏置
        - padding: (int, int)
            None:根据卷积核计算得到\n
        example:
        - inputs: (N, in_size, H, W)
        - outputs: (N, out_size, H, W)
    """

    def __init__(self,
                 in_size,
                 out_size,
                 kernel_size,
                 bias=True,
                 padding=None):
        super().__init__()
        self.in_size = in_size
        self.out_size = out_size
        self.kernel_size = kernel_size
        self.bias = None if bias == True else bias
        if padding is None:
            self.padding = kernel_size//2 if isinstance(
                kernel_size, int) else (kernel_size[0]//2, kernel_size[1]//2)
        else:
            self.padding = padding
        self.qkv_conv2d = nn.Conv2D(self.in_size,
                                    3*self.out_size,
                                    self.kernel_size,
                                    padding=self.padding,
                                    bias_attr=self.bias)
        self.softmax = nn.Softmax(axis=-1)
        self.norm_factor = 1.0/(self.out_size**0.5)

    def forward(self, inputs):
        QKV = self.qkv_conv2d(inputs)
        Q, K, V = paddle.split(QKV, 3, axis=-3)
        bs, c, h, w = K.shape
        Q = Q.reshape([-1, h, w])
        K = K.reshape([-1, h, w]).transpose(perm=[0, 2, 1])
        V = V.reshape([-1, h, w])
        QK = paddle.bmm(Q, K)*self.norm_factor
        QK = QK.reshape([-1, h*h])
        QK = self.softmax(QK)
        QK = QK.reshape([-1, h, h])
        outputs = paddle.bmm(QK, V)

        return outputs.reshape([bs, c, h, w])


# %% [markdown]
# ## End

# %%



