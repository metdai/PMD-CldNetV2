# %% [markdown]
# # FCNN
# 
# FCNN: Fully Connected/Convlutional Neural Network for PaddlePaddle

# %% [markdown]
# ## 导入函数库

# %%
import paddle
import paddle.nn as nn
from .ConvRNN import ConvLSTM, ConvGRU
from .Attention import Attention1d, Attention2d


# %% [markdown]
# ## 主架构

# %%
"""
Created on Mon September 06 09:16:36 2021
全网络结构
@author: BEOH
"""


class FCNN(nn.Layer):
    def __init__(self, network=None, is_print=False):
        super().__init__()
        if network == None:
            self.network = [{
                "name": "Linear",
                "in_features": 36,
                "out_features": 18
            },
                {
                "name": "ReLU"
            },
                {
                "name": "BatchNorm1d",
                "num_features": 18
            },
                {
                "name": "Dropout1d",
                "p": 0.2
            },
                {
                "name": "Linear",
                "in_features": 18,
                "out_features": 2
            }]
        else:
            self.network = network
        self.is_print = is_print

        net_list = []
        for i in range(len(self.network)):
            if self.network[i]["name"] == "Linear":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Linear(self.network[i]["in_features"],
                                          self.network[i]["out_features"]))
            elif self.network[i]["name"] == "LSTM":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "num_layers" not in self.network[i]:
                    self.network[i]["num_layers"] = 1
                if "dropout_rate" not in self.network[i]:
                    self.network[i]["dropout_rate"] = 0.0
                net_list.append(nn.LSTM(self.network[i]["input_size"],
                                        self.network[i]["hidden_size"],
                                        self.network[i]["num_layers"],
                                        dropout=self.network[i]["dropout_rate"]))
            elif self.network[i]["name"] == "GRU":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "num_layers" not in self.network[i]:
                    self.network[i]["num_layers"] = 1
                if "dropout_rate" not in self.network[i]:
                    self.network[i]["dropout_rate"] = 0.0
                net_list.append(nn.GRU(self.network[i]["input_size"],
                                       self.network[i]["hidden_size"],
                                       self.network[i]["num_layers"],
                                       dropout=self.network[i]["dropout_rate"]))
            elif self.network[i]["name"] == "Conv2d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "stride" not in self.network[i]:
                    self.network[i]["stride"] = 1
                if "padding" not in self.network[i]:
                    self.network[i]["padding"] = 0
                net_list.append(nn.Conv2D(self.network[i]["in_channels"],
                                          self.network[i]["out_channels"],
                                          self.network[i]["kernel_size"],
                                          stride=self.network[i]["stride"],
                                          padding=self.network[i]["padding"]))
            elif self.network[i]["name"] == "ConvLSTM":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "kernel_size" not in self.network[i]:
                    self.network[i]["kernel_size"] = 3
                if "num_layers" not in self.network[i]:
                    self.network[i]["num_layers"] = 1
                if "batch_first" not in self.network[i]:
                    self.network[i]["batch_first"] = True
                if "bias" not in self.network[i]:
                    self.network[i]["bias"] = True
                if "dropout_rate" not in self.network[i]:
                    self.network[i]["dropout_rate"] = 0.0
                net_list.append(ConvLSTM(self.network[i]["input_size"],
                                         self.network[i]["hidden_size"],
                                         self.network[i]["kernel_size"],
                                         num_layers=self.network[i]["num_layers"],
                                         batch_first=self.network[i]["batch_first"],
                                         bias=self.network[i]["bias"],
                                         dropout_rate=self.network[i]["dropout_rate"]))
            elif self.network[i]["name"] == "ConvGRU":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "kernel_size" not in self.network[i]:
                    self.network[i]["kernel_size"] = 3
                if "num_layers" not in self.network[i]:
                    self.network[i]["num_layers"] = 1
                if "batch_first" not in self.network[i]:
                    self.network[i]["batch_first"] = True
                if "bias" not in self.network[i]:
                    self.network[i]["bias"] = True
                if "dropout_rate" not in self.network[i]:
                    self.network[i]["dropout_rate"] = 0.0
                net_list.append(ConvGRU(self.network[i]["input_size"],
                                        self.network[i]["hidden_size"],
                                        self.network[i]["kernel_size"],
                                        num_layers=self.network[i]["num_layers"],
                                        batch_first=self.network[i]["batch_first"],
                                        bias=self.network[i]["bias"],
                                        dropout_rate=self.network[i]["dropout_rate"]))
            elif self.network[i]["name"] == "Attention1d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "bias" not in self.network[i]:
                    self.network[i]["bias"] = True
                net_list.append(Attention1d(self.network[i]["in_size"],
                                            self.network[i]["qk_size"],
                                            self.network[i]["out_size"],
                                            bias=self.network[i]["bias"]))
            elif self.network[i]["name"] == "Attention2d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "kernel_size" not in self.network[i]:
                    self.network[i]["kernel_size"] = 3
                if "bias" not in self.network[i]:
                    self.network[i]["bias"] = True
                if "padding" not in self.network[i]:
                    self.network[i]["padding"] = None
                net_list.append(Attention2d(self.network[i]["in_size"],
                                            self.network[i]["out_size"],
                                            self.network[i]["kernel_size"],
                                            bias=self.network[i]["bias"],
                                            padding=self.network[i]["padding"]))
            elif self.network[i]["name"] == "ReLU":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.ReLU())
            elif self.network[i]["name"] == "MaxPool1d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "stride" not in self.network[i]:
                    self.network[i]["stride"] = None
                if "padding" not in self.network[i]:
                    self.network[i]["padding"] = 0
                net_list.append(nn.MaxPool1D(self.network[i]["kernel_size"],
                                             stride=self.network[i]["stride"],
                                             padding=self.network[i]["padding"]))
            elif self.network[i]["name"] == "MaxPool2d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "stride" not in self.network[i]:
                    self.network[i]["stride"] = None
                if "padding" not in self.network[i]:
                    self.network[i]["padding"] = 0
                net_list.append(nn.MaxPool2D(self.network[i]["kernel_size"],
                                             stride=self.network[i]["stride"],
                                             padding=self.network[i]["padding"]))
            elif self.network[i]["name"] == "AvgPool1d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "stride" not in self.network[i]:
                    self.network[i]["stride"] = None
                if "padding" not in self.network[i]:
                    self.network[i]["padding"] = 0
                net_list.append(nn.AvgPool1D(self.network[i]["kernel_size"],
                                             stride=self.network[i]["stride"],
                                             padding=self.network[i]["padding"]))
            elif self.network[i]["name"] == "AvgPool2d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "stride" not in self.network[i]:
                    self.network[i]["stride"] = None
                if "padding" not in self.network[i]:
                    self.network[i]["padding"] = 0
                net_list.append(nn.AvgPool2D(self.network[i]["kernel_size"],
                                             stride=self.network[i]["stride"],
                                             padding=self.network[i]["padding"]))
            elif self.network[i]["name"] == "Dropout1d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Dropout(self.network[i]["p"]))
            elif self.network[i]["name"] == "Dropout2d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Dropout2D(self.network[i]["p"]))
            elif self.network[i]["name"] == "BatchNorm1d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.BatchNorm1D(
                    self.network[i]["num_features"]))
            elif self.network[i]["name"] == "BatchNorm2d":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.BatchNorm2D(
                    self.network[i]["num_features"]))
            elif self.network[i]["name"] == "reshape":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Identity())
            elif self.network[i]["name"] == "unsqueeze":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Identity())
            elif self.network[i]["name"] == "squeeze":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "dim" not in self.network[i]:
                    self.network[i]["dim"] = None
                net_list.append(nn.Identity())
            elif self.network[i]["name"] == "tile":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Identity())
            elif self.network[i]["name"] == "concat":
                if (not isinstance(self.network[i]["0"], list)) or (len(self.network[i]["0"]) < 2):
                    raise ValueError("需要含不少于2个变量的列表")
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Identity())
            elif self.network[i]["name"] == "stack":
                if (not isinstance(self.network[i]["0"], list)) or (len(self.network[i]["0"]) < 2):
                    raise ValueError("需要含不少于2个变量的列表")
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "dim" not in self.network[i]:
                    self.network[i]["dim"] = 0
                net_list.append(nn.Identity())
            elif self.network[i]["name"] == "add":
                if (not isinstance(self.network[i]["0"], list)) or (len(self.network[i]["0"]) < 2):
                    raise ValueError("需要含不少于2个变量的列表")
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Identity())
            elif self.network[i]["name"] == "clone":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Identity())
            elif self.network[i]["name"] == "mean":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Identity())
            elif self.network[i]["name"] == "select":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                net_list.append(nn.Identity())
            elif self.network[i]["name"] == "Conv2D_relu_bn":
                if "0" not in self.network[i]:
                    self.network[i]["0"] = "x0"
                if "1" not in self.network[i]:
                    self.network[i]["1"] = "x0"
                if "stride" not in self.network[i]:
                    self.network[i]["stride"] = 1
                if "padding" not in self.network[i]:
                    self.network[i]["padding"] = 0
                net_list.append(nn.Sequential(nn.Conv2D(self.network[i]["in_channels"],
                                                        self.network[i]["out_channels"],
                                                        self.network[i]["kernel_size"],
                                                        stride=self.network[i]["stride"],
                                                        padding=self.network[i]["padding"]),
                                              nn.ReLU(),
                                              nn.BatchNorm2D(self.network[i]["out_channels"])))
            elif self.network[i]["name"] == "Identity":
                net_list.append(nn.Identity())
            else:
                raise ValueError("不知名的模型网络层"+self.network[i]["name"])

        self.net_list = nn.LayerList(net_list)

    def forward(self, inputs):
        for i in range(len(self.network)):
            if self.network[i]["name"] == "reshape":
                inputs[self.network[i]["1"]] = paddle.reshape(inputs[self.network[i]["0"]],
                                                             self.network[i]["shape"])
            elif self.network[i]["name"] == "unsqueeze":
                inputs[self.network[i]["1"]] = paddle.unsqueeze(inputs[self.network[i]["0"]],
                                                               self.network[i]["dim"])
            elif self.network[i]["name"] == "squeeze":
                inputs[self.network[i]["1"]] = paddle.squeeze(inputs[self.network[i]["0"]],
                                                             self.network[i]["dim"])
            elif self.network[i]["name"] == "tile":
                inputs[self.network[i]["1"]] = paddle.tile(inputs[self.network[i]["0"]],
                                                          self.network[i]["dims"])
            elif self.network[i]["name"] == "concat":
                xx = []
                for idx in range(len(self.network[i]["0"])):
                    xx.append(inputs[self.network[i]["0"][idx]])
                inputs[self.network[i]["1"]] = paddle.concat(
                    xx, self.network[i]["dim"])
            elif self.network[i]["name"] == "stack":
                xx = []
                for idx in range(len(self.network[i]["0"])):
                    xx.append(inputs[self.network[i]["0"][idx]])
                inputs[self.network[i]["1"]] = paddle.stack(
                    xx, self.network[i]["dim"])
            elif self.network[i]["name"] == "LSTM":
                inputs[self.network[i]["1"]], _ = self.net_list[i](
                    inputs[self.network[i]["0"]])
            elif self.network[i]["name"] == "GRU":
                inputs[self.network[i]["1"]], _ = self.net_list[i](
                    inputs[self.network[i]["0"]])
            elif self.network[i]["name"] == "ConvLSTM":
                inputs[self.network[i]["1"]], _ = self.net_list[i](
                    inputs[self.network[i]["0"]])
            elif self.network[i]["name"] == "ConvGRU":
                inputs[self.network[i]["1"]], _ = self.net_list[i](
                    inputs[self.network[i]["0"]])
            elif self.network[i]["name"] == "add":
                inputs[self.network[i]["1"]] = inputs[self.network[i]["0"][0]]
                for idx in range(1, len(self.network[i]["0"])):
                    inputs[self.network[i]["1"]] = inputs[self.network[i]
                                                          ["1"]] + inputs[self.network[i]["0"][idx]]
            elif self.network[i]["name"] == "clone":
                inputs[self.network[i]["1"]
                       ] = inputs[self.network[i]["0"]].clone()
            elif self.network[i]["name"] == "mean":
                inputs[self.network[i]["1"]] = paddle.mean(inputs[self.network[i]["0"]],
                                                          self.network[i]["dim"])
            elif self.network[i]["name"] == "select":
                inputs[self.network[i]["1"]] = paddle.index_select(inputs[self.network[i]["0"]],
                                                                   paddle.to_tensor(self.network[i]["index"], dtype='int32'),
                                                                   axis=self.network[i]["dim"])
                inputs[self.network[i]["1"]] = paddle.squeeze(inputs[self.network[i]["1"]], axis=self.network[i]["dim"])
            else:
                inputs[self.network[i]["1"]] = self.net_list[i](
                    inputs[self.network[i]["0"]])

            if self.is_print:
                print("{0:>3d} {1:>12} : {2}, {3}".format(
                    i, self.network[i]["name"], inputs["x0"].shape, inputs["x0"].dtype))

        return inputs["x0"]


# %% [markdown]
# ## End

# %%
if __name__ == "__main__":
    # example of network
    network = [
        {
            "name": "Linear",
            "0": "x0",
            "1": "x0",
            "in_features": 3,
            "out_features": 5
        },
        {
            "name": "LSTM",
            "0": "x0",
            "1": "x0",
            "input_size": 3,
            "hidden_size": 5,
            "num_layers": 1,
            "dropout_rate": 0.0
        },
        {
            "name": "GRU",
            "0": "x0",
            "1": "x0",
            "input_size": 3,
            "hidden_size": 5,
            "num_layers": 1,
            "dropout_rate": 0.0
        },
        {
            "name": "Conv2d",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 3,
            "stride": 1,
            "padding": 0
        },
        {
            "name": "ConvLSTM",
            "0": "x0",
            "1": "x0",
            "input_size": 3,
            "hidden_size": 5,
            "kernel_size": 3,
            "num_layers": 1,
            "batch_first": True,
            "bias": True,
            "dropout_rate": 0.0
        },
        {
            "name": "ConvGRU",
            "0": "x0",
            "1": "x0",
            "input_size": 3,
            "hidden_size": 5,
            "kernel_size": 3,
            "num_layers": 1,
            "batch_first": True,
            "bias": True,
            "dropout_rate": 0.0
        },
        {
            "name": "Attention1d",
            "0": "x0",
            "1": "x0",
            "in_size": 3,
            "qk_size": 5,
            "out_size": 3,
            "bias": True
        },
        {
            "name": "Attention2d",
            "0": "x0",
            "1": "x0",
            "in_size": 3,
            "out_size": 5,
            "kernel_size": 3,
            "bias": True,
            "padding": 0
        },
        {
            "name": "ReLU",
            "0": "x0",
            "1": "x0"
        },
        {
            "name": "MaxPool1d",
            "kernel_size": 3,
            "stride": None,
            "padding": 0
        },
        {
            "name": "MaxPool2d",
            "kernel_size": 3,
            "stride": None,
            "padding": 0
        },
        {
            "name": "AvgPool1d",
            "kernel_size": 3,
            "stride": None,
            "padding": 0
        },
        {
            "name": "AvgPool2d",
            "kernel_size": 3,
            "stride": None,
            "padding": 0
        },
        {
            "name": "Dropout1d",
            "0": "x0",
            "1": "x0",
            "p": 0.0
        },
        {
            "name": "Dropout2d",
            "0": "x0",
            "1": "x0",
            "p": 0.0
        },
        {
            "name": "BatchNorm1d",
            "0": "x0",
            "1": "x0",
            "num_features": 3
        },
        {
            "name": "BatchNorm2d",
            "0": "x0",
            "1": "x0",
            "num_features": 3
        },
        {
            "name": "reshape",
            "0": "x0",
            "1": "x0",
            "shape": [3, 5, -1]
        },
        {
            "name": "unsqueeze",
            "0": "x0",
            "1": "x0",
            "dim": 2
        },
        {
            "name": "squeeze",
            "0": "x0",
            "1": "x0",
            "dim": 2
        },
        {
            "name": "tile",
            "0": "x0",
            "1": "x0",
            "dims": [1, 1, 3, 2]
        },
        {
            "name": "concat",
            "0": ["x0", "x1", "x2"],
            "1": "x0",
            "dim": 1
        },
        {
            "name": "stack",
            "0": "x0",
            "1": "x0",
            "dim": 2
        },
        {
            "name": "add",
            "0": ["x0", "x1", "x2"],
            "1": "x0"
        },
        {
            "name": "clone",
            "0": "x0",
            "1": "x0"
        },
        {
            "name": "mean",
            "0": "x0",
            "1": "x0",
            "dim": 2
        },
        {
            "name": "select",
            "0": "x0",
            "1": "x0",
            "dim": 1,
            "index": 2
        },
        {
            "name": "Conv2D_relu_bn",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 3,
            "stride": 1,
            "padding": 1
        },
        {
            "name": "Identity",
        },
        {
            "name": "NBlock",
            "num": 3,
            "network": [
                {
                    "name": "Linear",
                    "0": "x0",
                    "1": "x0",
                    "in_features": 3,
                    "out_features": 3
                },
                {
                    "name": "Identity",
                }
            ]
        }
    ]



