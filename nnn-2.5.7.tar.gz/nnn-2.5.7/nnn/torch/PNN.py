# %% [markdown]
# # PNN
# PNN: Parsing Neural Network
# 

# %%
from collections import OrderedDict


# %% [markdown]
# ## 主结构

# %%
class PNN():
    """
    Created on Sat January 01 15:39:20 2022
    PNN (Parsing Neural Network)
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(self):
        super().__init__()
        network = [
            {
                "name": "Linear",
                "in_features": 12,
                "out_features": 9
            },
            {
                "name": "ReLU"
            },
            {
                "name": "Linear",
                "in_features": 9,
                "out_features": 1
            }
        ]
        self.network = network

    def parsing(self, network=None, flag: int = 0):
        """参数:
        parsing: 解析成NNN能够识别的网络结构
        - network: dict
            {
                "net": {},
                "work": [],
            } if flag=0
        - network: dict
            {
                "init": {
                    "identifier": "Id04_{0}",
                    "name": "nn.Conv2d",
                    "args": {
                        "in_channels": 3,
                        "out_channels": 5,
                        "kernel_size": 3,
                        "stride": 1,
                        "padding": 0
                    }
                },
                "forward": {
                    # "identifier": "Id04_{0}",
                    "in": "x0",
                    "out": "x0"
                }
            } if flag=1
        """
        if network is None:
            network = self.network.copy()

        if flag == 0:
            return self.__parsing0(network)
        elif flag == 1:
            return self.__parsing1(network)

    def inout(self, xx=["x0"], prefix="ins['{0}']"):
        if not isinstance(xx, list):
            results = prefix.format(xx) if len(xx) != 0 else "_"
        else:
            results = prefix.format(xx[0]) if len(xx[0]) != 0 else "_"
            for x in xx[1:]:
                results = results + ", " + \
                    (prefix.format(x) if len(x) != 0 else "_")

        return results

    # 解析方式1
    def __parsing1(self, network):
        network_ = {'net': OrderedDict(), 'work': []}

        vvv_ = []
        for vvv in network:
            # 构建循环次数
            cycle = 1
            if 'cycle' in vvv:
                cycle = vvv['cycle']
            # 简单拉扯多个基本单元
            for _ in range(cycle):
                if 'block' in vvv:
                    vvv_ += vvv['block']
                else:
                    vvv_.append(vvv)
            # 将单元转化成network对应的字典和数组
        # print('*'*160)
        # print(vvv_)
        # print('*'*160)

        for ii, vv in enumerate(vvv_):
            # print('-'*60, ii, '-'*60)
            # print(vv)
            net_flag = False
            if "init" in vv and vv["init"]:
                if "identifier" not in vv["init"]:
                    vv["init"]["identifier"] = str(ii)
                Id = vv["init"]["identifier"].format(str(ii))

                if "net" in vv["init"]:
                    network_['net'][Id] = vv["init"]["net"]
                    net_flag = True
                elif "name" in vv["init"]:
                    network_['net'][Id] = "{0}(**{1})".format(
                        vv["init"]["name"],
                        vv["init"]["args"] if "args" in vv["init"] else dict()
                    )
                    net_flag = True

            if "forward" in vv:
                if "in" not in vv["forward"]:
                    vv["forward"]["in"] = "x0"
                if "out" not in vv["forward"]:
                    vv["forward"]["out"] = "x0"
                if "in_prefix1" not in vv["forward"]:
                    vv["forward"]["in_prefix1"] = "ins['{0}']"
                if "out_prefix1" not in vv["forward"]:
                    vv["forward"]["out_prefix1"] = "ins['{0}']"
                if "in_prefix2" not in vv["forward"]:
                    vv["forward"]["in_prefix2"] = "{0}"
                if "out_prefix2" not in vv["forward"]:
                    vv["forward"]["out_prefix2"] = "{0}"
                if "identifier" not in vv["forward"]:
                    vv["forward"]["identifier"] = vv["init"]["identifier"].format(
                        str(ii)) if net_flag else str(ii)
                Id = vv["forward"]["identifier"].format(str(ii))

                inin = vv["forward"]["in_prefix2"].format(self.inout(vv['forward']['in'], vv['forward']['in_prefix1']))
                outout = vv["forward"]["out_prefix2"].format(self.inout(vv['forward']['out'], vv['forward']['out_prefix1']))
                if "work" in vv["forward"]:
                    network_['work'].append(
                        vv["forward"]["work"].format(
                            outout,
                            Id,
                            inin,
                            vv['forward']['args'] if 'args' in vv['forward'] else {}
                        )
                    )
                elif "name" in vv["forward"]:
                    network_['work'].append(
                        f"{outout}={vv['forward']['name']}({inin}, **{vv['forward']['args']})"
                    )
                else:
                    network_['work'].append(
                        "{0}=self.MD['{1}']({2}, **{3})".format(
                            outout,
                            Id,
                            inin,
                            vv['forward']['args'] if 'args' in vv['forward'] else {}
                        )
                    )

        network = network_.copy()

        return network

    # 解析方式0

    def __parsing0(self, network):
        network_ = {'net': OrderedDict(), 'work': []}

        ii = 0
        for vvv in network:
            # 构建循环次数
            cycle = 1
            if 'cycle' in vvv:
                cycle = vvv['cycle']
            # 简单拉扯多个基本单元
            vvv_ = []
            for _ in range(cycle):
                if 'block' in vvv:
                    vvv_ += vvv['block']
                else:
                    vvv_.append(vvv)
            # 将单元转化成network对应的字典和数组
            for vv in vvv_:
                Id = vv["identifier"] if "identifier" in vv else str(ii)
                if vv["name"] == "Linear":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "bias" not in vv:
                        vv["bias"] = True
                    network_['net'][Id] = "nn.Linear({0},{1},bias={2}".format(
                        vv['in_features'],
                        vv['out_features'],
                        vv['bias']
                    )
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Bilinear":
                    if "0" not in vv:
                        vv["0"] = ["x0", "x0"]
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "bias" not in vv:
                        vv["bias"] = True
                    network_['net'][Id] = "nn.Bilinear({0},{1},{2}".format(
                        vv['in1_features'],
                        vv['in2_features'],
                        vv['out_features']
                    )
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'], ins['{3}'])".format(
                            vv['1'], Id, vv['0'][0], vv['0'][1])
                    )
                elif vv["name"] == "LazyLinear":
                    if "0" not in vv:
                        vv["0"] = ["x0", "x0"]
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "bias" not in vv:
                        vv["bias"] = True
                    network_['net'][Id] = "nn.LazyLinear({0}".format(
                        vv['out_features']
                    )
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'], ins['{3}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "LSTM":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "num_layers" not in vv:
                        vv["num_layers"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "batch_first" not in vv:
                        vv["batch_first"] = False
                    if "dropout" not in vv:
                        vv["dropout"] = 0
                    if "bidirectional" not in vv:
                        vv["bidirectional"] = False
                    if "proj_size" not in vv:
                        vv["proj_size"] = 0
                    network_["net"][Id] = "nn.LSTM({0},{1}".format(
                        vv['input_size'],
                        vv['hidden_size']
                    )
                    network_['net'][Id] += f",num_layers={vv['num_layers']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += f",batch_first={vv['batch_first']}"
                    network_['net'][Id] += f",dropout={vv['dropout']}"
                    network_[
                        'net'][Id] += f",bidirectional={vv['bidirectional']}"
                    network_['net'][Id] += f",proj_size={vv['proj_size']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "GRU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "num_layers" not in vv:
                        vv["num_layers"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "batch_first" not in vv:
                        vv["batch_first"] = False
                    if "dropout" not in vv:
                        vv["dropout"] = 0
                    if "bidirectional" not in vv:
                        vv["bidirectional"] = False
                    network_["net"][Id] = "nn.GRU({0},{1},{2}".format(
                        vv['input_size'],
                        vv['hidden_size']
                    )
                    network_['net'][Id] += f",num_layers={vv['num_layers']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += f",batch_first={vv['batch_first']}"
                    network_['net'][Id] += f",dropout={vv['dropout']}"
                    network_[
                        'net'][Id] += f",bidirectional={vv['bidirectional']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Conv1d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "nn.Conv1d({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Conv2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "nn.Conv2d({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Conv3d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "nn.Conv3d({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ConvTranspose1d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "output_padding" not in vv:
                        vv["output_padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "nn.ConvTranspose1d({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_[
                        'net'][Id] += f",output_padding={vv['output_padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ConvTranspose2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "output_padding" not in vv:
                        vv["output_padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "nn.ConvTranspose2d({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_[
                        'net'][Id] += f",output_padding={vv['output_padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ConvTranspose3d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "output_padding" not in vv:
                        vv["output_padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "nn.ConvTranspose3d({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_[
                        'net'][Id] += f",output_padding={vv['output_padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ELU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "alpha" not in vv:
                        vv["alpha"] = 1.0
                    if "inplace" not in vv:
                        vv["inplace"] = False
                    network_[
                        'net'][Id] = f"nn.ELU(alpha={vv['alpha']},inplace={vv['inplace']})"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ReLU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "inplace" not in vv:
                        vv["inplace"] = False
                    network_['net'][Id] = f"nn.ReLU(inplace={vv['inplace']})"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "LeakyReLU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "negative_slope" not in vv:
                        vv["negative_slope"] = 0.01
                    if "inplace" not in vv:
                        vv["inplace"] = False
                    network_[
                        'net'][Id] = f"nn.LeakyReLU(negative_slope={vv['negative_slope']},inplace={vv['inplace']})"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Sigmoid":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_['net'][Id] = f"nn.Sigmoid()"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "SiLU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_['net'][Id] = f"nn.SiLU()"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Tanh":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_['net'][Id] = f"nn.Tanh()"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Softmin":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dim" not in vv:
                        vv["dim"] = None
                    network_['net'][Id] = f"nn.Softmin(dim={vv['dim']})"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Softmax":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dim" not in vv:
                        vv["dim"] = None
                    network_['net'][Id] = f"nn.Softmax(dim={vv['dim']})"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Softmax2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_['net'][Id] = f"nn.Softmax2d()"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "LogSoftmax":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dim" not in vv:
                        vv["dim"] = None
                    network_['net'][Id] = f"nn.LogSoftmax(dim={vv['dim']})"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "AdaptiveLogSoftmaxWithLoss":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "div_value" not in vv:
                        vv["div_value"] = 4.0
                    if "head_bias" not in vv:
                        vv["head_bias"] = False
                    network_["net"][Id] = "nn.AdaptiveLogSoftmaxWithLoss({0},{1},{2}".format(
                        vv['in_features'],
                        vv['n_classes'],
                        vv['cutoffs']
                    )
                    network_['net'][Id] += f",div_value={vv['div_value']}"
                    network_['net'][Id] += f",head_bias={vv['head_bias']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "MultiheadAttention":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dropout" not in vv:
                        vv["dropout"] = 0.0
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "add_bias_kv" not in vv:
                        vv["add_bias_kv"] = False
                    if "add_zero_attn" not in vv:
                        vv["add_zero_attn"] = False
                    if "kdim" not in vv:
                        vv["kdim"] = None
                    if "vdim" not in vv:
                        vv["vdim"] = None
                    if "batch_first" not in vv:
                        vv["batch_first"] = False
                    network_["net"][Id] = "nn.MultiheadAttention({0},{1}".format(
                        vv['embed_dim'],
                        vv['num_heads']
                    )
                    network_['net'][Id] += f",dropout={vv['dropout']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += f",add_bias_kv={vv['add_bias_kv']}"
                    network_[
                        'net'][Id] += f",add_zero_attn={vv['add_zero_attn']}"
                    network_['net'][Id] += f",kdim={vv['kdim']}"
                    network_['net'][Id] += f",vdim={vv['vdim']}"
                    network_['net'][Id] += f",batch_first={vv['batch_first']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'], ins['{3}'], ins['{4}'])".format(
                            vv['1'], Id, vv['0'][0], vv['0'][1], vv['0'][2])
                    )
                elif vv["name"] == "Transformer":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "d_model" not in vv:
                        vv["d_model"] = 512
                    if "nhead" not in vv:
                        vv["nhead"] = 8
                    if "num_encoder_layers" not in vv:
                        vv["num_encoder_layers"] = 6
                    if "num_decoder_layers" not in vv:
                        vv["num_decoder_layers"] = 6
                    if "dim_feedforward" not in vv:
                        vv["dim_feedforward"] = 2048
                    if "dropout" not in vv:
                        vv["dropout"] = 0.1
                    if "activation" not in vv:
                        vv["activation"] = "relu"
                    if "custom_encoder" not in vv:
                        vv["custom_encoder"] = None
                    if "custom_decoder" not in vv:
                        vv["custom_decoder"] = None
                    if "layer_norm_eps" not in vv:
                        vv["layer_norm_eps"] = 1e-05
                    if "batch_first" not in vv:
                        vv["batch_first"] = False
                    if "norm_first" not in vv:
                        vv["norm_first"] = False
                    network_["net"][Id] = "nn.Transformer(d_model={0},nhead={1}".format(
                        vv['d_model'],
                        vv['nhead']
                    )
                    network_[
                        'net'][Id] += f",num_encoder_layers={vv['num_encoder_layers']}"
                    network_[
                        'net'][Id] += f",num_decoder_layers={vv['num_decoder_layers']}"
                    network_[
                        'net'][Id] += f",dim_feedforward={vv['dim_feedforward']}"
                    network_['net'][Id] += f",dropout={vv['dropout']}"
                    network_['net'][Id] += f",activation='{vv['activation']}'"
                    network_[
                        'net'][Id] += f",custom_encoder={vv['custom_encoder']}"
                    network_[
                        'net'][Id] += f",custom_decoder={vv['custom_decoder']}"
                    network_[
                        'net'][Id] += f",layer_norm_eps={vv['layer_norm_eps']}"
                    network_['net'][Id] += f",batch_first={vv['batch_first']}"
                    network_['net'][Id] += f",norm_first={vv['norm_first']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'], ins['{3}'])".format(
                            vv['1'], Id, vv['0'][0], vv['0'][1])
                    )
                elif vv["name"] == "TransformerEncoder":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "norm" not in vv:
                        vv["norm"] = None
                    if "enable_nested_tensor" not in vv:
                        vv["enable_nested_tensor"] = True
                    if "mask_check" not in vv:
                        vv["mask_check"] = True
                    network_["net"][Id] = "nn.TransformerEncoder({0},{1}".format(
                        vv['encoder_layer'],
                        vv['num_layers']
                    )
                    network_['net'][Id] += f",norm={vv['norm']}"
                    network_[
                        'net'][Id] += f",enable_nested_tensor={vv['enable_nested_tensor']}"
                    network_['net'][Id] += f",mask_check={vv['mask_check']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "TransformerDecoder":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "norm" not in vv:
                        vv["norm"] = None
                    network_["net"][Id] = "nn.TransformerDecoder({0},{1}".format(
                        vv['decoder_layer'],
                        vv['num_layers']
                    )
                    network_['net'][Id] += f",norm={vv['norm']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'], ins['{3}'])".format(
                            vv['1'], Id, vv['0'][0], vv['0'][1])
                    )
                elif vv["name"] == "TransformerEncoderLayer":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dim_feedforward" not in vv:
                        vv["dim_feedforward"] = 2048
                    if "dropout" not in vv:
                        vv["dropout"] = 0.1
                    if "activation" not in vv:
                        vv["activation"] = "relu"
                    if "layer_norm_eps" not in vv:
                        vv["layer_norm_eps"] = 1e-05
                    if "batch_first" not in vv:
                        vv["batch_first"] = False
                    if "norm_first" not in vv:
                        vv["norm_first"] = False
                    network_["net"][Id] = "nn.TransformerEncoderLayer({0},{1}".format(
                        vv['d_model'],
                        vv['nhead']
                    )
                    network_[
                        'net'][Id] += f",dim_feedforward={vv['dim_feedforward']}"
                    network_['net'][Id] += f",dropout={vv['dropout']}"
                    network_['net'][Id] += f",activation='{vv['activation']}'"
                    network_[
                        'net'][Id] += f",layer_norm_eps={vv['layer_norm_eps']}"
                    network_['net'][Id] += f",batch_first={vv['batch_first']}"
                    network_['net'][Id] += f",norm_first={vv['norm_first']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "TransformerDecoderLayer":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dim_feedforward" not in vv:
                        vv["dim_feedforward"] = 2048
                    if "dropout" not in vv:
                        vv["dropout"] = 0.1
                    if "activation" not in vv:
                        vv["activation"] = "relu"
                    if "layer_norm_eps" not in vv:
                        vv["layer_norm_eps"] = 1e-05
                    if "batch_first" not in vv:
                        vv["batch_first"] = False
                    if "norm_first" not in vv:
                        vv["norm_first"] = False
                    network_["net"][Id] = "nn.TransformerDecoderLayer({0},{1}".format(
                        vv['d_model'],
                        vv['nhead']
                    )
                    network_[
                        'net'][Id] += f",dim_feedforward={vv['dim_feedforward']}"
                    network_['net'][Id] += f",dropout={vv['dropout']}"
                    network_['net'][Id] += f",activation='{vv['activation']}'"
                    network_[
                        'net'][Id] += f",layer_norm_eps={vv['layer_norm_eps']}"
                    network_['net'][Id] += f",batch_first={vv['batch_first']}"
                    network_['net'][Id] += f",norm_first={vv['norm_first']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "MaxPool1d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = None
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "return_indices" not in vv:
                        vv["return_indices"] = False
                    if "ceil_mode" not in vv:
                        vv["ceil_mode"] = False
                    network_["net"][Id] = "nn.MaxPool1d({0}".format(
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_[
                        'net'][Id] += f",return_indices={vv['return_indices']}"
                    network_['net'][Id] += f",ceil_mode={vv['ceil_mode']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "MaxPool2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = None
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "return_indices" not in vv:
                        vv["return_indices"] = False
                    if "ceil_mode" not in vv:
                        vv["ceil_mode"] = False
                    network_["net"][Id] = "nn.MaxPool2d({0}".format(
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_[
                        'net'][Id] += f",return_indices={vv['return_indices']}"
                    network_['net'][Id] += f",ceil_mode={vv['ceil_mode']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "MaxPool3d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = None
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "return_indices" not in vv:
                        vv["return_indices"] = False
                    if "ceil_mode" not in vv:
                        vv["ceil_mode"] = False
                    network_["net"][Id] = "nn.MaxPool3d({0}".format(
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_[
                        'net'][Id] += f",return_indices={vv['return_indices']}"
                    network_['net'][Id] += f",ceil_mode={vv['ceil_mode']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "MaxUnpool1d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = None
                    if "padding" not in vv:
                        vv["padding"] = 0
                    network_["net"][Id] = "nn.MaxUnpool1d({0}".format(
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'], ins['{3}'])".format(
                            vv['1'], Id, vv['0'][0], vv['0'][1])
                    )
                elif vv["name"] == "MaxUnpool2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = None
                    if "padding" not in vv:
                        vv["padding"] = 0
                    network_["net"][Id] = "nn.MaxUnpool2d({0}".format(
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'], ins['{3}'])".format(
                            vv['1'], Id, vv['0'][0], vv['0'][1])
                    )
                elif vv["name"] == "MaxUnpool3d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = None
                    if "padding" not in vv:
                        vv["padding"] = 0
                    network_["net"][Id] = "nn.MaxUnpool3d({0}".format(
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'], ins['{3}'])".format(
                            vv['1'], Id, vv['0'][0], vv['0'][1])
                    )
                elif vv["name"] == "AdaptiveMaxPool1d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "return_indices" not in vv:
                        vv["return_indices"] = False
                    network_["net"][Id] = "nn.AdaptiveMaxPool1d({0}".format(
                        vv['output_size']
                    )
                    network_[
                        'net'][Id] += f",return_indices={vv['return_indices']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "AdaptiveMaxPool2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "return_indices" not in vv:
                        vv["return_indices"] = False
                    network_["net"][Id] = "nn.AdaptiveMaxPool2d({0}".format(
                        vv['output_size']
                    )
                    network_[
                        'net'][Id] += f",return_indices={vv['return_indices']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "AdaptiveMaxPool3d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "return_indices" not in vv:
                        vv["return_indices"] = False
                    network_["net"][Id] = "nn.AdaptiveMaxPool3d({0}".format(
                        vv['output_size']
                    )
                    network_[
                        'net'][Id] += f",return_indices={vv['return_indices']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "AvgPool1d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = None
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "ceil_mode" not in vv:
                        vv["ceil_mode"] = False
                    network_["net"][Id] = "nn.AvgPool1d({0}".format(
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",ceil_mode={vv['ceil_mode']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "AvgPool2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = None
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "ceil_mode" not in vv:
                        vv["ceil_mode"] = False
                    network_["net"][Id] = "nn.AvgPool2d({0}".format(
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",ceil_mode={vv['ceil_mode']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "AvgPool3d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = None
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "ceil_mode" not in vv:
                        vv["ceil_mode"] = False
                    network_["net"][Id] = "nn.AvgPool3d({0}".format(
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",ceil_mode={vv['ceil_mode']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "AdaptiveAvgPool1d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_["net"][Id] = "nn.AdaptiveAvgPool1d({0}".format(
                        vv['output_size']
                    )
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "AdaptiveAvgPool2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_["net"][Id] = "nn.AdaptiveAvgPool2d({0}".format(
                        vv['output_size']
                    )
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "AdaptiveAvgPool3d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_["net"][Id] = "nn.AdaptiveAvgPool3d({0}".format(
                        vv['output_size']
                    )
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Dropout":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "p" not in vv:
                        vv["p"] = 0.5
                    if "inplace" not in vv:
                        vv["inplace"] = False
                    network_["net"][Id] = "nn.Dropout("
                    network_['net'][Id] += f"p={vv['p']}"
                    network_['net'][Id] += f",inplace={vv['inplace']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Dropout1d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "p" not in vv:
                        vv["p"] = 0.5
                    if "inplace" not in vv:
                        vv["inplace"] = False
                    network_["net"][Id] = "nn.Dropout1d("
                    network_['net'][Id] += f"p={vv['p']}"
                    network_['net'][Id] += f",inplace={vv['inplace']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Dropout2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "p" not in vv:
                        vv["p"] = 0.5
                    if "inplace" not in vv:
                        vv["inplace"] = False
                    network_["net"][Id] = "nn.Dropout2d("
                    network_['net'][Id] += f"p={vv['p']}"
                    network_['net'][Id] += f",inplace={vv['inplace']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Dropout3d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "p" not in vv:
                        vv["p"] = 0.5
                    if "inplace" not in vv:
                        vv["inplace"] = False
                    network_["net"][Id] = "nn.Dropout3d("
                    network_['net'][Id] += f"p={vv['p']}"
                    network_['net'][Id] += f",inplace={vv['inplace']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "BatchNorm1d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "eps" not in vv:
                        vv["eps"] = 1e-05
                    if "momentum" not in vv:
                        vv["momentum"] = 0.1
                    if "affine" not in vv:
                        vv["affine"] = True
                    if "track_running_stats" not in vv:
                        vv["track_running_stats"] = True
                    network_["net"][Id] = "nn.BatchNorm1d({0}".format(
                        vv['num_features']
                    )
                    network_['net'][Id] += f",eps={vv['eps']}"
                    network_['net'][Id] += f",momentum={vv['momentum']}"
                    network_['net'][Id] += f",affine={vv['affine']}"
                    network_[
                        'net'][Id] += f",track_running_stats={vv['track_running_stats']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "BatchNorm2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "eps" not in vv:
                        vv["eps"] = 1e-05
                    if "momentum" not in vv:
                        vv["momentum"] = 0.1
                    if "affine" not in vv:
                        vv["affine"] = True
                    if "track_running_stats" not in vv:
                        vv["track_running_stats"] = True
                    network_["net"][Id] = "nn.BatchNorm2d({0}".format(
                        vv['num_features']
                    )
                    network_['net'][Id] += f",eps={vv['eps']}"
                    network_['net'][Id] += f",momentum={vv['momentum']}"
                    network_['net'][Id] += f",affine={vv['affine']}"
                    network_[
                        'net'][Id] += f",track_running_stats={vv['track_running_stats']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "BatchNorm3d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "eps" not in vv:
                        vv["eps"] = 1e-05
                    if "momentum" not in vv:
                        vv["momentum"] = 0.1
                    if "affine" not in vv:
                        vv["affine"] = True
                    if "track_running_stats" not in vv:
                        vv["track_running_stats"] = True
                    network_["net"][Id] = "nn.BatchNorm3d({0}".format(
                        vv['num_features']
                    )
                    network_['net'][Id] += f",eps={vv['eps']}"
                    network_['net'][Id] += f",momentum={vv['momentum']}"
                    network_['net'][Id] += f",affine={vv['affine']}"
                    network_[
                        'net'][Id] += f",track_running_stats={vv['track_running_stats']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "GroupNorm":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "eps" not in vv:
                        vv["eps"] = 1e-05
                    if "affine" not in vv:
                        vv["affine"] = True
                    network_["net"][Id] = "nn.GroupNorm({0},{1}".format(
                        vv['num_groups'],
                        vv['num_channels']
                    )
                    network_['net'][Id] += f",eps={vv['eps']}"
                    network_['net'][Id] += f",affine={vv['affine']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "LayerNorm":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "eps" not in vv:
                        vv["eps"] = 1e-05
                    if "elementwise_affine" not in vv:
                        vv["elementwise_affine"] = True
                    network_["net"][Id] = "nn.LayerNorm({0}".format(
                        vv['normalized_shape']
                    )
                    network_['net'][Id] += f",eps={vv['eps']}"
                    network_[
                        'net'][Id] += f",elementwise_affine={vv['elementwise_affine']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "PixelShuffle":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_["net"][Id] = "nn.PixelShuffle({0}".format(
                        vv['upscale_factor']
                    )
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "PixelUnshuffle":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_["net"][Id] = "nn.PixelUnshuffle({0}".format(
                        vv['downscale_factor']
                    )
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Upsample":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "size" not in vv:
                        vv["size"] = None
                    if "scale_factor" not in vv:
                        vv["scale_factor"] = None
                    if "mode" not in vv:
                        vv["mode"] = 'nearest'
                    if "align_corners" not in vv:
                        vv["align_corners"] = None
                    if "recompute_scale_factor" not in vv:
                        vv["recompute_scale_factor"] = None
                    network_["net"][Id] = "nn.Upsample("
                    network_['net'][Id] += f"size={vv['size']}"
                    network_[
                        'net'][Id] += f",scale_factor={vv['scale_factor']}"
                    network_['net'][Id] += f",mode='{vv['mode']}'"
                    network_[
                        'net'][Id] += f",align_corners={vv['align_corners']}"
                    network_[
                        'net'][Id] += f",recompute_scale_factor={vv['recompute_scale_factor']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "UpsamplingNearest2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "size" not in vv:
                        vv["size"] = None
                    if "scale_factor" not in vv:
                        vv["scale_factor"] = None
                    network_["net"][Id] = "nn.UpsamplingNearest2d("
                    network_['net'][Id] += f"size={vv['size']}"
                    network_[
                        'net'][Id] += f",scale_factor={vv['scale_factor']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "UpsamplingBilinear2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "size" not in vv:
                        vv["size"] = None
                    if "scale_factor" not in vv:
                        vv["scale_factor"] = None
                    network_["net"][Id] = "nn.UpsamplingBilinear2d("
                    network_['net'][Id] += f"size={vv['size']}"
                    network_[
                        'net'][Id] += f",scale_factor={vv['scale_factor']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "reshape":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_['work'].append(
                        "ins['{0}']=torch.reshape(ins['{1}'],{2})".format(
                            vv['1'], vv['0'], vv['shape'])
                    )
                elif vv["name"] == "unsqueeze":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_['work'].append(
                        "ins['{0}']=torch.unsqueeze(ins['{1}'],{2})".format(
                            vv['1'], vv['0'], vv['dim'])
                    )
                elif vv["name"] == "squeeze":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dim" not in vv:
                        vv["dim"] = None
                    network_['work'].append(
                        "ins['{0}']=torch.squeeze(ins['{1}'],dim={2})".format(
                            vv['1'], vv['0'], vv['dim'])
                    )
                elif vv["name"] == "tile":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_['work'].append(
                        "ins['{0}']=torch.tile(ins['{1}'],{2})".format(
                            vv['1'], vv['0'], vv['dims'])
                    )
                elif vv["name"] == "concat":
                    if (not isinstance(vv["0"], list)) or (len(vv["0"]) < 2):
                        raise ValueError("需要含不少于2个变量的列表")
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dim" not in vv:
                        vv["dim"] = 0
                    temp = f"ins['{vv['1']}']=torch.concat([ins['{vv['0'][0]}']"
                    for idx in range(1, len(vv["0"])):
                        temp += f", ins['{vv['0'][idx]}']"
                    temp += f"], dim={vv['dim']})"
                    network_['work'].append(
                        temp
                    )
                elif vv["name"] == "stack":
                    if (not isinstance(vv["0"], list)) or (len(vv["0"]) < 2):
                        raise ValueError("需要含不少于2个变量的列表")
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dim" not in vv:
                        vv["dim"] = 0
                    temp = f"ins['{vv['1']}']=torch.stack([ins['{vv['0'][0]}']"
                    for idx in range(1, len(vv["0"])):
                        temp += f", ins['{vv['0'][idx]}']"
                    temp += f"], dim={vv['dim']})"
                    network_['work'].append(
                        temp
                    )
                elif vv["name"] == "add":
                    if (not isinstance(vv["0"], list)) or (len(vv["0"]) < 2):
                        raise ValueError("需要含不少于2个变量的列表")
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "alpha" not in vv:
                        vv["alpha"] = 1
                    network_['work'].append(
                        "ins['{0}']=torch.add(ins['{1}'],ins['{2}'],alpha={3})".format(
                            vv['1'], vv['0'][0], vv['0'][1], vv['alpha'])
                    )
                elif vv["name"] == "clone":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_['work'].append(
                        "ins['{0}']=ins['{1}'].clone()".format(
                            vv['1'], vv['0'])
                    )
                elif vv["name"] == "mean":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dim" not in vv:
                        network_['work'].append(
                            "ins['{0}']=torch.mean(ins['{1}'])".format(
                                vv['1'], vv['0'])
                        )
                    else:
                        network_['work'].append(
                            "ins['{0}']=torch.mean(ins['{1}'],{2})".format(
                                vv['1'], vv['0'], vv['dim'])
                        )
                elif vv["name"] == "select":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_['work'].append(
                        "ins['{0}']=torch.select(ins['{1}'],{2},{3})".format(
                            vv['1'], vv['0'], vv['dim'], vv['index'])
                    )
                elif vv["name"] == "einops_rearrange":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "axes_lengths" not in vv:
                        vv["axes_lengths"] = {}
                    network_['work'].append(
                        "ins['{0}']=einops.rearrange(ins['{1}'],'{2}',**{3})".format(
                            vv['1'], vv['0'], vv['pattern'], vv['axes_lengths'])
                    )
                elif vv["name"] == "einops_reduce":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "reduction" not in vv:
                        vv["reduction"] = "mean"
                    if "axes_lengths" not in vv:
                        vv["axes_lengths"] = {}
                    network_['work'].append(
                        "ins['{0}']=einops.reduce(ins['{1}'],'{2}','{3}',**{4})".format(
                            vv['1'], vv['0'], vv['pattern'], vv['reduction'], vv['axes_lengths'])
                    )
                elif vv["name"] == "einops_repeat":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "axes_lengths" not in vv:
                        vv["axes_lengths"] = {}
                    network_['work'].append(
                        "ins['{0}']=einops.repeat(ins['{1}'],'{2}',**{3})".format(
                            vv['1'], vv['0'], vv['pattern'], vv['axes_lengths'])
                    )
                elif vv["name"] == "argmax":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dim" not in vv:
                        network_['work'].append(
                            "ins['{0}']=torch.argmax(ins['{1}'])".format(
                                vv['1'], vv['0'])
                        )
                    else:
                        if "keepdim" not in vv:
                            vv["keepdim"] = False
                        network_['work'].append(
                            "ins['{0}']=torch.argmax(ins['{1}'],{2},keepdim={3})".format(
                                vv['1'], vv['0'], vv['dim'], vv['keepdim'])
                        )
                elif vv["name"] == "Func_pad":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "mode" not in vv:
                        vv["mode"] = "constant"
                    if "value" not in vv:
                        vv["value"] = None
                    network_['work'].append(
                        "ins['{0}']=F.pad(ins['{1}'],{2},mode='{3}',value={3})".format(
                            vv['1'], vv['0'], vv['pad'], vv['mode'], vv['value'])
                    )
                elif vv["name"] == "ZeroPad2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_["net"][Id] = "nn.ZeroPad2d({0}".format(
                        vv['padding']
                    )
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Identity":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    network_["net"][Id] = "nn.Identity()"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Conv2d_ReLU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "Conv2d_ReLU({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ConvTranspose2d_ReLU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "output_padding" not in vv:
                        vv["output_padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "ConvTranspose2d_ReLU({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_[
                        'net'][Id] += f",output_padding={vv['output_padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Conv2d_ReLU_BN2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "Conv2d_ReLU_BN2d({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ConvTranspose2d_ReLU_BN2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "output_padding" not in vv:
                        vv["output_padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "ConvTranspose2d_ReLU_BN2d({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_[
                        'net'][Id] += f",output_padding={vv['output_padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Conv2d_BN2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "Conv2d_BN2d({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Conv2d_BN2d_ReLU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "Conv2d_BN2d_ReLU({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ConvTranspose2d_BN2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "output_padding" not in vv:
                        vv["output_padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "ConvTranspose2d_BN2d({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_[
                        'net'][Id] += f",output_padding={vv['output_padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ConvTranspose2d_BN2d_ReLU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "output_padding" not in vv:
                        vv["output_padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "groups" not in vv:
                        vv["groups"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "ConvTranspose2d_BN2d_ReLU({0},{1},{2}".format(
                        vv['in_channels'],
                        vv['out_channels'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_[
                        'net'][Id] += f",output_padding={vv['output_padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",groups={vv['groups']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "DepthwiseConv2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "kernel_size" not in vv:
                        vv["kernel_size"] = 3
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "DepthwiseConv2d({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",kernel_size={vv['kernel_size']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "DepthwiseConv2d_ReLU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "kernel_size" not in vv:
                        vv["kernel_size"] = 3
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "DepthwiseConv2d_ReLU({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",kernel_size={vv['kernel_size']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "DepthwiseConv2d_ReLU_BN2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "kernel_size" not in vv:
                        vv["kernel_size"] = 3
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "DepthwiseConv2d_ReLU_BN2d({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",kernel_size={vv['kernel_size']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "DepthwiseConv2d_BN2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "kernel_size" not in vv:
                        vv["kernel_size"] = 3
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "DepthwiseConv2d_BN2d({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",kernel_size={vv['kernel_size']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "DepthwiseConv2d_BN2d_ReLU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "kernel_size" not in vv:
                        vv["kernel_size"] = 3
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "padding" not in vv:
                        vv["padding"] = 0
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "DepthwiseConv2d_BN2d_ReLU({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",kernel_size={vv['kernel_size']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",padding={vv['padding']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "SqueezeExcitation":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "squeeze_factor" not in vv:
                        vv["squeeze_factor"] = 4
                    network_["net"][Id] = "SqueezeExcitation({0},{1}".format(
                        vv['in_channels'],
                        vv['expand_channels']
                    )
                    network_[
                        'net'][Id] += f",squeeze_factor={vv['squeeze_factor']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "MBConv2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "kernel_size" not in vv:
                        vv["kernel_size"] = 3
                    if "expand_factor" not in vv:
                        vv["expand_factor"] = 6
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "squeeze_factor" not in vv:
                        vv["squeeze_factor"] = None
                    if "p" not in vv:
                        vv["p"] = 0.2
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "bias" not in vv:
                        vv["bias"] = False
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "MBConv2d({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",kernel_size={vv['kernel_size']}"
                    network_[
                        'net'][Id] += f",expand_factor={vv['expand_factor']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_[
                        'net'][Id] += f",squeeze_factor={vv['squeeze_factor']}"
                    network_['net'][Id] += f",p={vv['p']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "FusedMBConv2d":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "kernel_size" not in vv:
                        vv["kernel_size"] = 3
                    if "expand_factor" not in vv:
                        vv["expand_factor"] = 4
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "squeeze_factor" not in vv:
                        vv["squeeze_factor"] = None
                    if "p" not in vv:
                        vv["p"] = 0.2
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "bias" not in vv:
                        vv["bias"] = False
                    if "padding_mode" not in vv:
                        vv["padding_mode"] = 'zeros'
                    network_["net"][Id] = "FusedMBConv2d({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",kernel_size={vv['kernel_size']}"
                    network_[
                        'net'][Id] += f",expand_factor={vv['expand_factor']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_[
                        'net'][Id] += f",squeeze_factor={vv['squeeze_factor']}"
                    network_['net'][Id] += f",p={vv['p']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_[
                        'net'][Id] += f",padding_mode='{vv['padding_mode']}'"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Basicblock":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "downsample" not in vv:
                        vv["downsample"] = False
                    if "squeeze_factor" not in vv:
                        vv["squeeze_factor"] = 1
                    network_["net"][Id] = "Basicblock({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",downsample={vv['downsample']}"
                    network_[
                        'net'][Id] += f",squeeze_factor={vv['squeeze_factor']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "Bottleneck":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "dilation" not in vv:
                        vv["dilation"] = 1
                    if "downsample" not in vv:
                        vv["downsample"] = False
                    if "squeeze_factor" not in vv:
                        vv["squeeze_factor"] = 4
                    network_["net"][Id] = "Bottleneck({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",dilation={vv['dilation']}"
                    network_['net'][Id] += f",downsample={vv['downsample']}"
                    network_[
                        'net'][Id] += f",squeeze_factor={vv['squeeze_factor']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ASPP":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dilation" not in vv:
                        vv["dilation"] = [1, 6, 12, 18]
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "is_bn" not in vv:
                        vv["is_bn"] = True
                    if "is_act" not in vv:
                        vv["is_act"] = True
                    if "bias2" not in vv:
                        vv["bias2"] = True
                    if "stride2" not in vv:
                        vv["stride2"] = 1
                    if "is_bn2" not in vv:
                        vv["is_bn2"] = True
                    if "is_act2" not in vv:
                        vv["is_act2"] = True
                    network_["net"][Id] = "ASPP({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",dilations={vv['dilations']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",is_bn={vv['is_bn']}"
                    network_['net'][Id] += f",is_act={vv['is_act']}"
                    network_['net'][Id] += f",bias2={vv['bias2']}"
                    network_['net'][Id] += f",stride2={vv['stride2']}"
                    network_['net'][Id] += f",is_bn2={vv['is_bn2']}"
                    network_['net'][Id] += f",is_act2={vv['is_act2']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "DepthwiseASPP":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "dilation" not in vv:
                        vv["dilation"] = [1, 6, 12, 18]
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "stride" not in vv:
                        vv["stride"] = 1
                    if "is_bn" not in vv:
                        vv["is_bn"] = True
                    if "is_act" not in vv:
                        vv["is_act"] = True
                    if "bias2" not in vv:
                        vv["bias2"] = True
                    if "stride2" not in vv:
                        vv["stride2"] = 1
                    if "is_bn2" not in vv:
                        vv["is_bn2"] = True
                    if "is_act2" not in vv:
                        vv["is_act2"] = True
                    network_["net"][Id] = "DepthwiseASPP({0},{1}".format(
                        vv['in_channels'],
                        vv['out_channels']
                    )
                    network_['net'][Id] += f",dilations={vv['dilations']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += f",stride={vv['stride']}"
                    network_['net'][Id] += f",is_bn={vv['is_bn']}"
                    network_['net'][Id] += f",is_act={vv['is_act']}"
                    network_['net'][Id] += f",bias2={vv['bias2']}"
                    network_['net'][Id] += f",stride2={vv['stride2']}"
                    network_['net'][Id] += f",is_bn2={vv['is_bn2']}"
                    network_['net'][Id] += f",is_act2={vv['is_act2']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ConvLSTM":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "kernel_size" not in vv:
                        vv["kernel_size"] = 3
                    if "num_layers" not in vv:
                        vv["num_layers"] = 1
                    if "batch_first" not in vv:
                        vv["batch_first"] = True
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "dropout" not in vv:
                        vv["dropout"] = 0.0
                    network_["net"][Id] = "ConvLSTM({0},{1},{2}".format(
                        vv['input_size'],
                        vv['hidden_size'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",num_layers={vv['num_layers']}"
                    network_['net'][Id] += f",batch_first={vv['batch_first']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += f",dropout_rate={vv['dropout']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "ConvGRU":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "kernel_size" not in vv:
                        vv["kernel_size"] = 3
                    if "num_layers" not in vv:
                        vv["num_layers"] = 1
                    if "batch_first" not in vv:
                        vv["batch_first"] = True
                    if "bias" not in vv:
                        vv["bias"] = True
                    if "dropout" not in vv:
                        vv["dropout"] = 0.0
                    network_["net"][Id] = "ConvGRU({0},{1},{2}".format(
                        vv['input_size'],
                        vv['hidden_size'],
                        vv['kernel_size']
                    )
                    network_['net'][Id] += f",num_layers={vv['num_layers']}"
                    network_['net'][Id] += f",batch_first={vv['batch_first']}"
                    network_['net'][Id] += f",bias={vv['bias']}"
                    network_['net'][Id] += f",dropout_rate={vv['dropout']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "DropPath":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "p" not in vv:
                        vv["p"] = 0.5
                    if "inplace" not in vv:
                        vv["inplace"] = False
                    network_["net"][Id] = "DropPath("
                    network_['net'][Id] += f"p={vv['p']}"
                    network_['net'][Id] += ")"
                    network_['work'].append(
                        "ins['{0}']=self.MD['{1}'](ins['{2}'])".format(
                            vv['1'], Id, vv['0'])
                    )
                elif vv["name"] == "slice":
                    if "0" not in vv:
                        vv["0"] = "x0"
                    if "1" not in vv:
                        vv["1"] = "x0"
                    if "slice" not in vv:
                        vv["kernel_size"] = "[0]"
                    if "clone" not in vv:
                        vv["clone"] = False
                    if vv["clone"]:
                        network_['work'].append(
                            "ins['{0}']=ins['{1}']".format(
                                vv['1'], vv['0'])+vv['slice']+".clone()"
                        )
                    else:
                        network_['work'].append(
                            "ins['{0}']=ins['{1}']".format(
                                vv['1'], vv['0'])+vv['slice']
                        )
                elif vv["name"] == "NNNCell":
                    if "net" in vv and vv["net"] is not None:
                        # "nn.ReLU(inplace=True)"
                        network_['net'][Id] = vv["net"]
                    if "work" in vv and vv["work"] is not None:
                        # "ins['x0']=self.MD['{0}'](ins['x1'])"
                        if "net" in vv and vv["net"] is not None:
                            network_['work'].append(vv["work"].format(Id))
                        else:
                            network_['work'].append(vv["work"])
                else:
                    raise ValueError("不知名的模型网络层"+vv["name"])

                ii = ii + 1
        network = network_.copy()

        return network


# %% [markdown]
# # End

# %% [markdown]
# ## 网络结构示例

# %%
if __name__ == "__main__":
    # example of network
    network = [
        {
            "name": "NNNCell",
            "net": "nn.ReLU(inplace=True)",
            "work": "ins['x0']=self.MD['{0}'](ins['x1'])"
        },
        {
            "name": "DepthwiseConv2d",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 3,
            "stride": 1,
            "padding": 0,
            "dilation": 1,
            "bias": True,
            "padding_mode": "zeros"
        },
        {
            "name": "DropPath",
            "p": 0.3
        },
        {
            "name": "Linear",
            "0": "x0",
            "1": "x0",
            "in_features": 3,
            "out_features": 5,
            "bias": True,
        },
        {
            "name": "LSTM",
            "0": "x0",
            "1": "x0",
            "input_size": 3,
            "hidden_size": 5,
            "num_layers": 1,
            "dropout": 0.0
        },
        {
            "name": "GRU",
            "0": "x0",
            "1": "x0",
            "input_size": 3,
            "hidden_size": 5,
            "num_layers": 1,
            "dropout": 0.0
        },
        {
            "name": "Conv2d",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 3,
            "stride": 1,
            "padding": 0
        },
        {
            "name": "ConvTranspose2d",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 4,
            "stride": 2,
            "padding": 1,
            "output_padding": 0
        },
        {
            "name": "ConvLSTM",
            "0": "x0",
            "1": "x0",
            "input_size": 3,
            "hidden_size": 5,
            "kernel_size": 3,
            "num_layers": 1,
            "batch_first": True,
            "bias": True,
            "dropout": 0.0
        },
        {
            "name": "ConvGRU",
            "0": "x0",
            "1": "x0",
            "input_size": 3,
            "hidden_size": 5,
            "kernel_size": 3,
            "num_layers": 1,
            "batch_first": True,
            "bias": True,
            "dropout": 0.0
        },
        {
            "name": "Attention1d",
            "0": "x0",
            "1": "x0",
            "in_size": 3,
            "qk_size": 5,
            "out_size": 3,
            "bias": True
        },
        {
            "name": "Attention2d",
            "0": "x0",
            "1": "x0",
            "in_size": 3,
            "out_size": 5,
            "kernel_size": 3,
            "bias": True,
            "padding": 0
        },
        {
            "name": "ELU",
            "0": "x0",
            "1": "x0",
            "alpha": 1.0,
            "inplace": False
        },
        {
            "name": "ReLU",
            "0": "x0",
            "1": "x0"
        },
        {
            "name": "Sigmoid",
            "0": "x0",
            "1": "x0"
        },
        {
            "name": "Tanh",
            "0": "x0",
            "1": "x0"
        },
        {
            "name": "Softmax",
            "0": "x0",
            "1": "x0",
            "dim": None
        },
        {
            "name": "Softmax2d",
            "0": "x0",
            "1": "x0"
        },
        {
            "name": "MaxPool1d",
            "kernel_size": 3,
            "stride": None,
            "padding": 0,
            "dilation": 1,
            "return_indices": False,
            "ceil_mode": False,
        },
        {
            "name": "MaxPool2d",
            "kernel_size": 3,
            "stride": None,
            "padding": 0,
            "dilation": 1,
            "return_indices": False,
            "ceil_mode": False,
        },
        {
            "name": "MaxPool3d",
            "kernel_size": 3,
            "stride": None,
            "padding": 0,
            "dilation": 1,
            "return_indices": False,
            "ceil_mode": False,
        },
        {
            "name": "AdaptiveMaxPool1d",
            "output_size": 5,
            "return_indices": False
        },
        {
            "name": "AdaptiveMaxPool2d",
            "output_size": [5, 8],
            "return_indices": False
        },
        {
            "name": "AdaptiveMaxPool3d",
            "output_size": [None, 5, 8],
            "return_indices": False
        },
        {
            "name": "AvgPool1d",
            "kernel_size": 3,
            "stride": None,
            "padding": 0
        },
        {
            "name": "AvgPool2d",
            "kernel_size": 3,
            "stride": None,
            "padding": 0
        },
        {
            "name": "AdaptiveAvgPool1d",
            "output_size": 5
        },
        {
            "name": "AdaptiveAvgPool2d",
            "output_size": [5, 8]
        },
        {
            "name": "AdaptiveAvgPool3d",
            "output_size": [None, 5, 8]
        },
        {
            "name": "Dropout1d",
            "0": "x0",
            "1": "x0",
            "p": 0.0
        },
        {
            "name": "Dropout2d",
            "0": "x0",
            "1": "x0",
            "p": 0.0
        },
        {
            "name": "Dropout3d",
            "0": "x0",
            "1": "x0",
            "p": 0.0
        },
        {
            "name": "BatchNorm1d",
            "0": "x0",
            "1": "x0",
            "num_features": 3
        },
        {
            "name": "BatchNorm2d",
            "0": "x0",
            "1": "x0",
            "num_features": 3
        },
        {
            "name": "BatchNorm3d",
            "0": "x0",
            "1": "x0",
            "num_features": 3
        },
        {
            "name": "Upsample",
            "0": "x0",
            "1": "x0",
            "size": None,
            "scale_factor": None,
            "mode": 'nearest',
            "align_corners": None,
            "recompute_scale_factor": None,
        },
        {
            "name": "UpsamplingNearest2d",
            "0": "x0",
            "1": "x0",
            "size": None,
            "scale_factor": None,
        },
        {
            "name": "UpsamplingBilinear2d",
            "0": "x0",
            "1": "x0",
            "size": None,
            "scale_factor": None,
        },
        {
            "name": "Func_pad",
            "0": "x0",
            "1": "x0",
            "pad": [2, 3],
            "mode": 'constant',
            "value": None
        },
        {
            "name": "ZeroPad2d",
            "0": "x0",
            "1": "x0",
            "padding": 2
        },
        {
            "name": "reshape",
            "0": "x0",
            "1": "x0",
            "shape": [3, 5, -1]
        },
        {
            "name": "unsqueeze",
            "0": "x0",
            "1": "x0",
            "dim": 2
        },
        {
            "name": "squeeze",
            "0": "x0",
            "1": "x0",
            "dim": 2
        },
        {
            "name": "tile",
            "0": "x0",
            "1": "x0",
            "dims": [1, 1, 3, 2]
        },
        {
            "name": "concat",
            "0": ["x0", "x1", "x2"],
            "1": "x0",
            "dim": 1
        },
        {
            "name": "stack",
            "0": "x0",
            "1": "x0",
            "dim": 2
        },
        {
            "name": "add",
            "0": ["x0", "x1"],
            "1": "x0"
        },
        {
            "name": "clone",
            "0": "x0",
            "1": "x0"
        },
        {
            "name": "mean",
            "0": "x0",
            "1": "x0",
            "dim": 2
        },
        {
            "name": "select",
            "0": "x0",
            "1": "x0",
            "dim": 1,
            "index": 2
        },
        {
            "name": "einops_rearrange",
            "0": "x0",
            "1": "x0",
            "pattern": "t b c -> b c t",
            "axes_lengths": {}
        },
        {
            "name": "einops_reduce",
            "0": "x0",
            "1": "x0",
            "pattern": "b c (h h2) (w w2) -> b h w c",
            "reduction": "mean",
            "axes_lengths": {
                "h2": 2,
                "w2": 2
            }
        },
        {
            "name": "einops_repeat",
            "0": "x0",
            "1": "x0",
            "pattern": "h w -> h w c",
            "axes_lengths": {
                "c": 3
            }
        },
        {
            "name": "argmax",
            "0": "x0",
            "1": "x0",
            "dim": 1,
            "keepdim": False
        },
        {
            "name": "Conv2d_ReLU",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 3,
            "stride": 1,
            "padding": 1
        },
        {
            "name": "Conv2d_ReLU_BN2d",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 3,
            "stride": 1,
            "padding": 1
        },
        {
            "name": "Conv2d_BN2d_ReLU",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 3,
            "stride": 1,
            "padding": 1
        },
        {
            "name": "ConvTranspose2d_ReLU",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 3,
            "stride": 2,
            "padding": 1,
            "output_padding": 0
        },
        {
            "name": "ConvTranspose2d_ReLU_BN2d",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 3,
            "stride": 2,
            "padding": 1,
            "output_padding": 0
        },
        {
            "name": "ConvTranspose2d_BN2d_ReLU",
            "0": "x0",
            "1": "x0",
            "in_channels": 3,
            "out_channels": 5,
            "kernel_size": 3,
            "stride": 2,
            "padding": 1,
            "output_padding": 0,
            "dilation": 1,
            "groups": 1,
            "bias": True,
            "padding_mode": 'zeros'
        },
        {
            "name": "slice",
            "0": "x0",
            "1": "x0",
            "slice": "[1:8, 2:9]",
            "clone": False
        },
        {
            "name": "Identity"
        }
    ]


# %% [markdown]
# ## 新的网络结构示例

# %%
if __name__ == "__main__":
    # example of network
    # Id = vv["identifier"] if "identifier" in vv else str(ii)
    network = [
        {
            "init": {
                "identifier": "Id01",
                "name": "DropPath",
                "args": {
                    "p": 0.3
                }
            },
            "forward": {
                # "identifier": "Id01",
                "in": "x0",
                "out": "x0"
            }
        },
        {
            "init": {
                "identifier": "Id02",
                "name": "nn.Linear",
                "args": {
                    "in_features": 3,
                    "out_features": 5,
                    "bias": True
                }
            },
            "forward": {
                "in": "x0",
                "out": "x0"
            }
        },
        {
            "init": {
                "identifier": "Id03",
                "name": "nn.LSTM",
                "args": {
                    "input_size": 3,
                    "hidden_size": 5,
                    "num_layers": 1,
                    "dropout": 0.0
                }
            },
            "forward": {
                "in": "x0",
                "out": "x0"
            }
        },
        {
            "init": {
                "identifier": "Id04",
                "name": "nn.Conv2d",
                "args": {
                    "in_channels": 3,
                    "out_channels": 5,
                    "kernel_size": 3,
                    "stride": 1,
                    "padding": 0
                }
            },
            "forward": {
                "in": "x0",
                "out": "x0"
            }
        },
        {
            "init": {},
            "forward": {
                "name": "torch.reshape",
                "in": "x0",
                "out": "x0",
                "args": {
                    "shape": [3, 5, -1]
                }
            }
        },
        {
            "init": {},
            "forward": {
                "name": "F.unsqueeze",
                "in": "x0",
                "out": "x0",
                "args": {
                    "dim": 2
                }
            }
        },
        {
            "init": {
                # "identifier": "Id05",
                "net": "nn.ReLU(inplace=True)",
            },
            "forward": {
                # "identifier": "Id05",
                "work": "ins['x0']=self.MD['{0}'](ins['x1'])"
            }
        },
        {
            "init": {
                "identifier": "Id05",
                "net": "nn.ReLU(inplace=True)",
            },
            "forward": {
                "work": "ins['x0']=self.MD['Id05'](ins['x1'])"
            }
        }
    ]


# %% [markdown]
# ## 函数接收参数示例

# %%
# if __name__ == "__main__":
#     def func(a, b=1, *args, **kwargs):
#         print(a)
#         print(b)
#         print(args)
#         print(kwargs)
#         return a, b

#     def func1(a, b=1, c=9, *args, **kwargs):
#         print(a)
#         print(b)
#         print(c)
#         print(kwargs)

#     def func2(a, b, c=9, d=20, e=30):
#         print(a)
#         print(b)
#         print(c)
#         print(d)
#         print(e)

#     cc = {"x1": 1, "x2": 3}
#     _ = func(2)
#     cc["x1"]

#     print('-'*120)
#     func1(a=70, c=3, b=20, t=2)
#     print('-'*120)
#     x = {"a": 10, "b": 20, "c": 30}
#     func2(**x)
#     print('-'*120)
#     print(func2)


#     def func3(a):
#         print(a)

#     func3(3, **{})


# %%



