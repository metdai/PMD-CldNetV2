# %% [markdown]
# # Workflow

# %% [markdown]
# ## 导入库

# %%
import torch
import torch.nn as nn

# %% [markdown]
# ## 主模块

# %%
class FLOW:
    def __init__(
        self,
        model=None,
        dataloader=None,
        criterion=None,
        optimizer=None,
        scheduler=None,
        func_pre=None,
        func_loss=None,
        func_post=None,
        logger=None,
    ):
        """
        input:
        - model: 模型
        - dataloader: 数据加载器
        - criterion: 评价器, default: None. [criterion0, criterion1]
        - optimizer: 优化器, default: None.
        - scheduler: 学习率调整器, default: None.
        - start_epoch: 第几轮, default: None.
        - func_pre: 模型输入前, default: None.
        - func_loss: 损失函数, default: None.
        - func_post: 后处理, default: None.
        - logger: 记录器, default: None.\n
        ---
        @Created on Sat January 01 15:39:20 2022
        @模型全流程
        @author: nielongfeng
        @email: nielongfeng@outlook.com
        """
        super().__init__()
        self.model = model
        self.dataloader = dataloader
        self.criterion = criterion
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.func_pre = func_pre
        self.func_loss = func_loss
        self.func_post = func_post
        self.logger = logger

        self.device = next(self.model.parameters()).device
        if self.func_pre is None and not callable(self.func_pre):
            self.func_pre = self.__func_pre
        if self.func_loss is None and not callable(self.func_loss):
            self.func_loss = self.__func_loss
        if self.func_post is None and not callable(self.func_post):
            self.func_post = self.__func_post

        if self.criterion is None:
            self.criterion = self.__get_criterion()
        if self.optimizer is None:
            self.optimizer = self.__get_optimizer()
        if self.scheduler is None:
            self.scheduler = self.__get_scheduler()

    def demon(
        self,
        stage: str = "train",
        epoch: int = None,
        accumulation: int = 1,
        log_level: int = 10,
        log_batch: int = None,
        model=None,
        dataloader=None,
        criterion=None,
        optimizer=None,
        scheduler=None,
        func_pre=None,
        func_loss=None,
        func_post=None,
        logger=None,
    ):
        """
        input:
        - stage: "train".
        - epoch: 当前epoch, default: None.
        - accumulation: 累计梯度更新的次数, default: 1.
        - log_level: 记录器级别, default: 10.
        - log_batch: 每num个batch输出一次到屏幕, default: None.\n
        ---
        @Created on Sat January 01 15:39:20 2022
        @模型全流程
        @author: nielongfeng
        @email: nielongfeng@outlook.com
        """
        # addition
        if model is not None:
            self.model = model
        if dataloader is not None:
            self.dataloader = dataloader
        if criterion is not None:
            self.criterion = criterion
        if optimizer is not None:
            self.optimizer = optimizer
        if scheduler is not None:
            self.scheduler = scheduler
        if func_pre is not None:
            self.func_pre = func_pre
        if func_loss is not None:
            self.func_loss = func_loss
        if func_post is not None:
            self.func_post = func_post
        if logger is not None:
            self.logger = logger
        # addition


        self.epoch = epoch
        self.is_train = stage in ["train", "Train"]
        self.is_validation = stage in ["validation", "Validation"]
        self.is_inference = stage in ["test", "Test", "inference", "Inference"]
        if not (self.is_train or self.is_validation or self.is_inference):
            raise ValueError("stage is wrong")

        if self.is_train:
            self.model.train()  # 切换模型为训练模式
        else:
            self.model.eval()  # 非训练状态下切换模型为评估模型
        with torch.set_grad_enabled(self.is_train):
            for self.batch, self.batch_data in enumerate(self.dataloader):
                self.out_txt = f"Epoch: {self.epoch}\tBatch: {self.batch}\t"

                # 模型输入数据准备
                self.func_pre(self)
                # 前向计算
                self.outputs = self.model(self.inputs)
                # 损失值计算
                if (
                    not self.is_inference
                    and self.criterion is not None
                    and self.func_loss is not None
                    and callable(self.func_loss)
                ):
                    self.func_loss(self)
                    if self.is_train:
                        # 训练过程反向传播
                        self.loss.backward()  # 反向传播，计算每层参数的梯度值
                        # 每accumulation个batch更新一次网络参数
                        if (self.batch + 1) % accumulation == 0:
                            self.optimizer.step()  # 更新参数，根据设置好的学习率迭代一步
                            self.optimizer.zero_grad()  # 梯度清零

                # 模型后处理
                self.func_post(self)

                # 打印部分结果到屏幕上
                if (
                    self.logger is not None
                    and log_batch is not None
                    and self.batch % log_batch == 0
                ):
                    self.logger.log(log_level, self.out_txt)
            if (
                self.logger is not None
                and log_batch is not None
                and self.batch % log_batch != 0
            ):
                self.logger.log(log_level, self.out_txt)

    def run(
        self,
        epochs: int,
        start_epoch: int = 0,
        accumulation: int = 1,
        log_epoch: int = None,
        log_batch: int = None,
        log_level: int = 10,
    ):
        """
        input:
        - epochs: 总轮数
        - start_epoch: 开始轮标记, default: 0.
        - accumulation: 累计梯度更新的次数, default: 1.
        - log_epoch: 每num个epoch输出一次到屏幕, default: None.
        - log_batch: 每num个batch输出一次到屏幕, default: None.
        - log_level: 记录器级别, default: 10.\n
        ---
        @Created on Sat January 01 15:39:20 2022
        @模型全流程
        @author: nielongfeng
        @email: nielongfeng@outlook.com
        """
        if self.logger is not None:
            self.logger.info("-" * 15 + "Run Start" + "-" * 15)

        for epoch in range(start_epoch, epochs):
            self.demon(
                epoch=epoch,
                accumulation=accumulation,
                log_batch=log_batch,
                log_level=log_level,
            )

            if self.scheduler is not None:
                self.scheduler.step()

            if (
                self.logger is not None
                and log_epoch is not None
                and (epoch % log_epoch == 0 or epoch + 1 == epochs)
            ):
                self.logger.log(
                    log_level,
                    f"Epoch: {epoch}\tTotal loss: {round(self.loss.tolist(), 8)}\n",
                )

    def __func_pre(self, _self):
        if not self.is_inference:
            _self.inputs = _self.batch_data[0]
            _self.refs = _self.batch_data[-1]
            if not isinstance(self.model, nn.DataParallel):
                _self.inputs = _self.inputs.to(self.device)
                _self.refs = _self.refs.to(self.device)
            _self.batch_data = None
        else:
            _self.inputs = _self.batch_data
            if not isinstance(self.model, nn.DataParallel):
                _self.inputs = _self.inputs.to(self.device)
            _self.batch_data = None

    def __func_loss(self, _self):
        _self.loss = _self.criterion(_self.outputs, _self.refs)
        _self.out_txt = _self.out_txt + f"loss: {round(_self.loss.tolist(), 8)}\t"

    def __func_post(self, _self):
        pass

    def __get_criterion(self):
        return nn.MSELoss()

    def __get_optimizer(self):
        return torch.optim.SGD(self.model.parameters(), lr=0.1)

    def __get_scheduler(self):
        return torch.optim.lr_scheduler.ExponentialLR(self.optimizer, gamma=0.9)

# %% [markdown]
# # End

# %%
# import numpy as np

# a = (np.ones((3, 5)), np.zeros((3, 5)))
# print(a, id(a))
# print("-"*60)
# b = a[0]
# b[0, 0] = 999
# print("b", b, id(b))
# print("a", a, id(a))
# print("-"*60)
# a = None
# print("a", a, id(a))
# print("b", b, id(b))

# %%
# class Net:
#     def __init__(self, func01=None):
#         self.a = 3
#         if func01 is None:
#             self.func01 = self.__func01
#         else:
#             self.func01 = func01

#     def func(self):
#         self.b = 5
#         self.func01(self)
#         print("-" * 50 + "func" + "-" * 50)
#         print(id(self), dir(self))
#         print("-" * 100)

#     def __func01(self, _self):
#         print("-" * 50 + "__func01" + "-" * 50)
#         print(id(_self), dir(_self))
#         print("-" * 100)


# def func00(_self):
#     print("-" * 50 + "func00" + "-" * 50)
#     _self.c = 6
#     print(id(_self), dir(_self))
#     print("-" * 100)


# net = Net()
# net.func()
# print(net.a, net.b)

# print("*" * 100)
# net = Net(func01=func00)
# net.func()
# print(net.a, net.b, net.c)

# %%
# import numpy as np

# x = np.ones((3, 5))
# print(x, id(x))
# print("--" * 25)


# def func(a):
#     print(a, id(a))
#     a[0, 0] = 999
#     print(a, id(a))


# func(x)
# print("--" * 25)
# print(x, id(x))

# %%
# if not isinstance(self.model, nn.DataParallel):
#     if self.inputs not in [None, [], {}] and isinstance(
#         self.inputs, (dict,)
#     ):
#         for inputs_key in self.inputs.keys():
#             self.inputs[inputs_key] = self.inputs[inputs_key].to(
#                 self.device
#             )
#     if self.refs not in [None, [], {}] and isinstance(
#         self.refs, (dict,)
#     ):
#         for refs_key in self.refs.keys():
#             self.refs[refs_key] = self.refs[refs_key].to(self.device)


