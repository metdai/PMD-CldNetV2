# %% [markdown]
# # NNN
# 
# NNN: N Neural Network

# %% [markdown]
# ## 导入函数库

# %%
import torch
import torch.nn as nn
import torch.nn.functional as F
import einops

from .NNNCell import DropPath
from .NNNCell import Conv2d_ReLU, Conv2d_ReLU_BN2d, Conv2d_BN2d, Conv2d_BN2d_ReLU, Conv2d_BN2d_LeakyReLU
from .NNNCell import ConvTranspose2d_ReLU, ConvTranspose2d_ReLU_BN2d, ConvTranspose2d_BN2d, ConvTranspose2d_BN2d_ReLU
from .NNNCell import DepthwiseConv2d, DepthwiseConv2d_ReLU, DepthwiseConv2d_ReLU_BN2d, DepthwiseConv2d_BN2d, DepthwiseConv2d_BN2d_ReLU
from .NNNCell import MBConv2d, FusedMBConv2d, SqueezeExcitation
from .NNNCell import Basicblock, Bottleneck
from .NNNCell import ResNet18, ResNet34, ResNet50, ResNet101, ResNet152
from .NNNCell import ASPP, DepthwiseASPP
from .NNNCell import ConvLSTMCell, ConvLSTM
from .NNNCell import ConvGRUCell, ConvGRU
from .NNNCell import SPP, Darkblock, DarkNet53, CSPDarkblock, CSPDarkNet53, ConvSetBlock
from .NNNCell import YOLOv1plus, YOLOv3


# %% [markdown]
# ## 主架构

# %%
class NNN(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    NNN (N Neural Network)
    @author: BEOH
    @email: beoh86@yeah.net
    """
    def __init__(self, network=None, is_print:bool=False):
        super().__init__()
        if network == None:
            self.network = {
                "net": {
                    "L1": "nn.Linear(2, 3)",
                    "L2": "nn.Linear(3, 3)",
                    "L3": "nn.Linear(3, 5)"
                },
                "work": [
                    "s['x0']=self.MD['L1'](s['x0'])",
                    "s['x0']=self.MD['L2'](s['x0'])",
                    "s['x0']=self.MD['L3'](s['x0'])"
                ]
            }
        else:
            self.network = network
            
        self.is_print = is_print
        self.dummy_param = nn.Parameter(torch.empty(0))
        self.MD = nn.ModuleDict(
            {k: eval(v) for k, v in self.network["net"].items()}
        )
    
    def forward(self, ins):
        device = self.dummy_param.device
        if self.is_print:
            print("Device: {0}".format(device))

        for work in self.network["work"]:
            exec(work)
            # cmpcode = compile(work, '<string>', 'exec')
            # exec(cmpcode)

            if self.is_print:
                for k, v in ins.items():
                    if isinstance(v, torch.Tensor):
                        print(k, v.shape)
                    elif isinstance(v, (list, tuple)):
                        for v_ in v:
                            if isinstance(v_, torch.Tensor):
                                print(k, v_.shape)
                print('---------------------------------------')
        
        return ins


# %% [markdown]
# ## End

# %%









