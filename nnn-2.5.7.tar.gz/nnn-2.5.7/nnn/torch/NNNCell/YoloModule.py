# %% [markdown]
# # YoloModule

# %%
import torch
import torch.nn as nn
import torch.nn.functional as F
from .ConvModule import Conv2d_BN2d, Conv2d_BN2d_ReLU, Conv2d_BN2d_LeakyReLU
from .ResNetModule import ResNet18


# %% [markdown]
# ## SPP

# %%
import torch.nn as nn
import torch.nn.functional as F


class SPP(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    SPP from [YOLO]
    """

    def __init__(
        self,
        kernel_size_list=[1, 5, 9, 13]
    ):
        """
        :params kernel_size_list: 默认[1, 5, 9, 13]
        """
        super().__init__()
        self.kernel_size_list = kernel_size_list

    def forward(self, x):
        x = torch.cat(
            [F.max_pool2d(x, kernel_size, stride=1, padding=kernel_size//2)
             for kernel_size in self.kernel_size_list],
            dim=1
        )

        return x


# %% [markdown]
# ## Darkblock

# %%
class Darkblock(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    Darkblock from [YOLO]
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        bias=True,
        stride=1,
        dilation=1,
        squeeze_factor: int = 2,
        negative_slope: float = 0.1,
        inplace: bool = True,
        num_block=1
    ):
        """
        :params in_channels
        :params out_channels
        :params bias: 默认True
        :params stride: 默认1
        :params dilation: 默认1
        :params squeeze_factor: 默认2
        :params negative_slope: 默认0.1
        :params inplace: 默认True
        :params num_block: 默认1
        """
        super().__init__()
        squeeze_channels = out_channels // squeeze_factor
        self.convs = nn.ModuleList()
        for ii in range(num_block):
            self.convs.append(
                nn.Sequential(
                    Conv2d_BN2d_LeakyReLU(
                        in_channels,
                        squeeze_channels,
                        1,
                        stride=stride,
                        padding=0,
                        dilation=dilation,
                        bias=bias,
                        negative_slope=negative_slope,
                        inplace=inplace
                    ),
                    Conv2d_BN2d_LeakyReLU(
                        squeeze_channels,
                        out_channels,
                        3,
                        stride=stride,
                        padding=dilation,
                        dilation=dilation,
                        bias=bias,
                        negative_slope=negative_slope,
                        inplace=inplace
                    )
                )
            )

    def forward(self, x):
        for conv in self.convs:
            x = x+conv(x)
        return x


# %% [markdown]
# ## CSPDarkblock

# %%
class CSPDarkblock(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    CSPDarkblock from [YOLO]
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        bias=True,
        stride=1,
        dilation=1,
        squeeze_factor: int = 2,
        negative_slope: float = 0.1,
        inplace: bool = False,
        num_block=1
    ):
        """
        :params in_channels
        :params out_channels
        :params bias: 默认True
        :params stride: 默认1
        :params dilation: 默认1
        :params squeeze_factor: 默认2
        :params negative_slope: 默认0.1
        :params inplace: 默认True
        :params num_block: 默认1
        """
        super().__init__()
        squeeze_channels = out_channels // squeeze_factor
        self.conv1 = Conv2d_BN2d_LeakyReLU(
            in_channels,
            squeeze_channels,
            1,
            stride=stride,
            padding=0,
            dilation=dilation,
            bias=bias,
            negative_slope=negative_slope,
            inplace=False
        )
        self.conv2 = Conv2d_BN2d_LeakyReLU(
            in_channels,
            squeeze_channels,
            1,
            stride=stride,
            padding=0,
            dilation=dilation,
            bias=bias,
            negative_slope=negative_slope,
            inplace=False
        )
        self.convs = nn.ModuleList()
        for ii in range(num_block):
            self.convs.append(
                nn.Sequential(
                    Conv2d_BN2d_LeakyReLU(
                        squeeze_channels,
                        squeeze_channels,
                        1,
                        stride=stride,
                        padding=0,
                        dilation=dilation,
                        bias=bias,
                        negative_slope=negative_slope,
                        inplace=inplace
                    ),
                    Conv2d_BN2d(
                        squeeze_channels,
                        squeeze_channels,
                        3,
                        stride=stride,
                        padding=dilation,
                        dilation=dilation,
                        bias=bias
                    )
                )
            )
        self.act = nn.LeakyReLU(0.1)
        self.conv3 = Conv2d_BN2d_LeakyReLU(
            squeeze_channels*2,
            out_channels,
            1,
            stride=stride,
            padding=0,
            dilation=dilation,
            bias=bias,
            negative_slope=negative_slope,
            inplace=inplace
        )

    def forward(self, x):
        x0 = self.conv1(x)
        x = self.conv2(x)
        for conv in self.convs:
            x = self.act(x+conv(x))
        return self.conv3(torch.cat([x0, x], dim=1))


# %% [markdown]
# ## DarkNet53

# %%
class DarkNet53(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    DarkNet53 from [YOLO]
    """

    def __init__(
        self,
        in_channels: int,
        last_layer_use: bool = False,
        num_classes=1000
    ):
        """
        :params in_channels
        :params last_layer: 默认False
        :params num_classes: 默认1000
        """
        super().__init__()
        self.layer1 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(in_channels, 32, 3,
                                  padding=1, negative_slope=0.1, inplace=True),
            Conv2d_BN2d_LeakyReLU(32, 64, 3, padding=1,
                                  stride=2, negative_slope=0.1, inplace=True),
            Darkblock(64, 64, num_block=1)
        )
        self.layer2 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(64, 128, 3, padding=1,
                                  stride=2, negative_slope=0.1, inplace=True),
            Darkblock(128, 128, num_block=2)
        )
        self.layer3 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(128, 256, 3, padding=1,
                                  stride=2, negative_slope=0.1, inplace=True),
            Darkblock(256, 256, num_block=8)
        )
        self.layer4 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(256, 512, 3, padding=1,
                                  stride=2, negative_slope=0.1, inplace=True),
            Darkblock(512, 512, num_block=8)
        )
        self.layer5 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(512, 1024, 3, padding=1,
                                  stride=2, negative_slope=0.1, inplace=True),
            Darkblock(1024, 1024, num_block=4)
        )
        self.last_layer_use = last_layer_use
        if last_layer_use:
            self.last_layer = nn.Sequential(
                nn.AdaptiveAvgPool2d((1, 1)),
                nn.Conv2d(1024, num_classes, 1)
            )

    def forward(self, x):
        c1 = self.layer1(x)
        c2 = self.layer2(c1)
        c3 = self.layer3(c2)
        c4 = self.layer4(c3)
        c5 = self.layer5(c4)
        if self.last_layer_use:
            return self.last_layer(c5).reshape(x.shape[0], -1)
        else:
            return c3, c4, c5


# %% [markdown]
# ## CSPDarkNet53

# %%
class CSPDarkNet53(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    CSPDarkNet53 from [YOLO]
    """

    def __init__(
        self,
        in_channels: int,
        last_layer_use: bool = False,
        num_classes=1000
    ):
        """
        :params in_channels
        :params last_layer: 默认False
        :params num_classes: 默认1000
        """
        super().__init__()
        self.layer1 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(in_channels, 32, 3,
                                  padding=1, negative_slope=0.1, inplace=True),
            Conv2d_BN2d_LeakyReLU(32, 64, 3, padding=1,
                                  stride=2, negative_slope=0.1, inplace=True),
            CSPDarkblock(64, 64, num_block=1)
        )
        self.layer2 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(64, 128, 3, padding=1,
                                  stride=2, negative_slope=0.1, inplace=True),
            CSPDarkblock(128, 128, num_block=2)
        )
        self.layer3 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(128, 256, 3, padding=1,
                                  stride=2, negative_slope=0.1, inplace=True),
            CSPDarkblock(256, 256, num_block=8)
        )
        self.layer4 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(256, 512, 3, padding=1,
                                  stride=2, negative_slope=0.1, inplace=True),
            CSPDarkblock(512, 512, num_block=8)
        )
        self.layer5 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(512, 1024, 3, padding=1,
                                  stride=2, negative_slope=0.1, inplace=True),
            CSPDarkblock(1024, 1024, num_block=4)
        )
        self.last_layer_use = last_layer_use
        if last_layer_use:
            self.last_layer = nn.Sequential(
                nn.AdaptiveAvgPool2d((1, 1)),
                nn.Conv2d(1024, num_classes, 1)
            )

    def forward(self, x):
        c1 = self.layer1(x)
        c2 = self.layer2(c1)
        c3 = self.layer3(c2)
        c4 = self.layer4(c3)
        c5 = self.layer5(c4)
        if self.last_layer_use:
            return self.last_layer(c5).reshape(x.shape[0], -1)
        else:
            return c3, c4, c5


# %% [markdown]
# ## ConvSetBlock

# %%
class ConvSetBlock(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ConvSetBlock from [YOLO]
    """

    def __init__(
        self,
        in_channels,
        out_channels
    ):
        """
        :params in_channels
        :params out_channels
        """
        super().__init__()

        self.ConvSetBlock = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(in_channels, out_channels,
                                  1, padding=0, negative_slope=0.1),
            Conv2d_BN2d_LeakyReLU(out_channels, in_channels,
                                  3, padding=1, negative_slope=0.1),
            Conv2d_BN2d_LeakyReLU(in_channels, out_channels,
                                  1, padding=0, negative_slope=0.1),
            Conv2d_BN2d_LeakyReLU(out_channels, in_channels,
                                  3, padding=1, negative_slope=0.1),
            Conv2d_BN2d_LeakyReLU(in_channels, out_channels,
                                  1, padding=0, negative_slope=0.1)
        )

    def forward(self, x):
        return self.ConvSetBlock(x)


# %% [markdown]
# ## YOLOv1plus

# %%
class YOLOv1plus(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    YOLOv1plus from [YOLO]
    """

    def __init__(
        self,
        in_channels: int = 3,
        num_anchors: int = 1,
        num_classes: int = 20
    ):
        """
        :params in_channels: 默认3
        :params num_anchors: 默认1
        :params num_classes: 默认20
        """
        super().__init__()
        self.num_anchors = num_anchors
        self.num_classes = num_classes

        # 主干网络
        self.backbone = ResNet18(in_channels, last_layer_use=False)

        # neck
        self.neck = nn.Sequential(
            SPP([1, 5, 9, 13]),
            Conv2d_BN2d_ReLU(512*4, 512, 1)
        )

        # detection head
        self.head = nn.Sequential(
            Conv2d_BN2d_ReLU(512, 512//2, 1),
            Conv2d_BN2d_ReLU(512//2, 512, 3, padding=1),
            Conv2d_BN2d_ReLU(512, 512//2, 1),
            Conv2d_BN2d_ReLU(512//2, 512, 3, padding=1),
            nn.Conv2d(512, (1+4+self.num_classes)*self.num_anchors, 1)
        )

    def forward(self, x):
        x = self.backbone(x)
        x = self.neck(x)
        x = self.head(x)

        return x


# %% [markdown]
# ## YOLOv3

# %%
class YOLOv3(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    YOLOv3 from [YOLO]
    """

    def __init__(
        self,
        in_channels: int = 3,
        num_anchors: int = 1,
        num_classes: int = 20
    ):
        """
        :params in_channels: 默认3
        :params num_anchors: 默认1
        :params num_classes: 默认20
        """
        super().__init__()
        self.num_anchors = num_anchors
        self.num_classes = num_classes

        # 主干网络
        self.backbone = DarkNet53(in_channels)

        # c5
        self.ConvSet_c5 = ConvSetBlock(1024, 512)
        self.pre_c5 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(512, 1024, 3, padding=1, negative_slope=0.1),
            nn.Conv2d(1024, (1+4+self.num_classes)*self.num_anchors, 1)
        )
        self.CBL_c5 = Conv2d_BN2d_LeakyReLU(
            512, 256, 1, padding=0, negative_slope=0.1)
        # c4
        self.ConvSet_c4 = ConvSetBlock(768, 256)
        self.pre_c4 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(256, 512, 3, padding=1, negative_slope=0.1),
            nn.Conv2d(512, (1+4+self.num_classes)*self.num_anchors, 1)
        )
        self.CBL_c4 = Conv2d_BN2d_LeakyReLU(
            256, 128, 1, padding=0, negative_slope=0.1)
        # c3
        self.ConvSet_c3 = ConvSetBlock(384, 128)
        self.pre_c3 = nn.Sequential(
            Conv2d_BN2d_LeakyReLU(128, 256, 3, padding=1, negative_slope=0.1),
            nn.Conv2d(256, (1+4+self.num_classes)*self.num_anchors, 1)
        )

    def forward(self, x):
        c3, c4, c5 = self.backbone(x)

        c5 = self.ConvSet_c5(c5)
        p5 = self.pre_c5(c5)

        c5 = F.interpolate(self.CBL_c5(c5), scale_factor=2, mode='bilinear')
        c4 = torch.cat([c4, c5], dim=1)
        c4 = self.ConvSet_c4(c4)
        p4 = self.pre_c4(c4)

        c4 = F.interpolate(self.CBL_c4(c4), scale_factor=2, mode='bilinear')
        c3 = torch.cat([c3, c4], dim=1)
        c3 = self.ConvSet_c3(c3)
        p3 = self.pre_c3(c3)

        return p3, p4, p5


# %% [markdown]
# # End

# %%



