# %% [markdown]
# # ConvTransposeModule

# %%
import torch.nn as nn


# %% [markdown]
# ## ConvTranspose2d_ReLU

# %%
class ConvTranspose2d_ReLU(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ConvTranspose2d_ReLU
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        stride=1,
        padding=0,
        output_padding=0,
        dilation=1,
        groups=1,
        bias=True,
        padding_mode='zeros'
    ):
        super().__init__()
        self.ConvTranspose2d_ReLU = nn.Sequential(
            nn.ConvTranspose2d(
                in_channels,
                out_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                output_padding=output_padding,
                dilation=dilation,
                groups=groups,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.ReLU()
        )

    def forward(self, x):
        return self.ConvTranspose2d_ReLU(x)


# %% [markdown]
# ## ConvTranspose2d_ReLU_BN2d

# %%
class ConvTranspose2d_ReLU_BN2d(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ConvTranspose2d_ReLU_BN2d
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        stride=1,
        padding=0,
        output_padding=0,
        dilation=1,
        groups=1,
        bias=True,
        padding_mode='zeros'
    ):
        super().__init__()
        self.ConvTranspose2d_ReLU_BN2d = nn.Sequential(
            nn.ConvTranspose2d(
                in_channels,
                out_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                output_padding=output_padding,
                dilation=dilation,
                groups=groups,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.ReLU(),
            nn.BatchNorm2d(out_channels)
        )

    def forward(self, x):
        return self.ConvTranspose2d_ReLU_BN2d(x)


# %% [markdown]
# ## ConvTranspose2d_BN2d

# %%
class ConvTranspose2d_BN2d(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ConvTranspose2d_BN2d
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        stride=1,
        padding=0,
        output_padding=0,
        dilation=1,
        groups=1,
        bias=True,
        padding_mode='zeros'
    ):
        super().__init__()
        self.ConvTranspose2d_BN2d = nn.Sequential(
            nn.ConvTranspose2d(
                in_channels,
                out_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                output_padding=output_padding,
                dilation=dilation,
                groups=groups,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.BatchNorm2d(out_channels)
        )

    def forward(self, x):
        return self.ConvTranspose2d_BN2d(x)


# %% [markdown]
# ## ConvTranspose2d_BN2d_ReLU

# %%
class ConvTranspose2d_BN2d_ReLU(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ConvTranspose2d_BN2d_ReLU
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size,
        stride=1,
        padding=0,
        output_padding=0,
        dilation=1,
        groups=1,
        bias=True,
        padding_mode='zeros'
    ):
        super().__init__()
        self.ConvTranspose2d_BN2d_ReLU = nn.Sequential(
            nn.ConvTranspose2d(
                in_channels,
                out_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                output_padding=output_padding,
                dilation=dilation,
                groups=groups,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        )

    def forward(self, x):
        return self.ConvTranspose2d_BN2d_ReLU(x)



