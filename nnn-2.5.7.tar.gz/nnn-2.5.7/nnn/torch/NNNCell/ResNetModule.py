# %% [markdown]
# # ResNetModule

# %%
import torch.nn as nn
from .ConvModule import Conv2d_BN2d_ReLU


# %% [markdown]
# ## Basicblock
# 
# Res18，Res34

# %%
class Basicblock(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    Basicblock from [Deep Residual Learning for Image Recognition]
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        bias=True,
        stride=1,
        dilation=1,
        downsample: bool = False,
        squeeze_factor: int = 1
    ):
        """
        :params in_channels
        :params out_channels
        :params bias: 默认True
        :params stride: 默认1
        :params dilation: 默认1
        :params downsample: 默认False
        :params squeeze_factor: 默认1
        """
        super().__init__()
        squeeze_channels = out_channels // squeeze_factor
        # 01
        self.conv1 = nn.Conv2d(
            in_channels,
            squeeze_channels,
            3,
            stride=stride,
            padding=dilation,
            dilation=dilation,
            bias=bias
        )
        self.bn1 = nn.BatchNorm2d(squeeze_channels)
        self.act1 = nn.ReLU()
        # 02
        self.conv2 = nn.Conv2d(
            squeeze_channels,
            out_channels,
            3,
            stride=1,
            padding=dilation,
            dilation=dilation,
            bias=bias
        )
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.act2 = nn.ReLU()
        # 11
        self.downsample = downsample
        if (in_channels != out_channels or stride != 1):
            self.downsample = True
        if self.downsample:
            self.conv_ = nn.Conv2d(
                in_channels,
                out_channels,
                1,
                stride=stride,
                bias=bias
            )
            self.bn_ = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        x0 = x
        x = self.act1(self.bn1(self.conv1(x)))
        x = self.bn2(self.conv2(x))
        if self.downsample:
            x0 = self.bn_(self.conv_(x0))
        return self.act2(x+x0)


# %% [markdown]
# ## Bottleneck
# 
# Res50，Res101，Res152

# %%
class Bottleneck(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    Bottleneck from [Deep Residual Learning for Image Recognition]
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        bias=True,
        stride=1,
        dilation=1,
        downsample: bool = False,
        squeeze_factor: int = 4
    ):
        """
        :params in_channels
        :params out_channels
        :params bias: 默认True
        :params stride: 默认1
        :params dilation: 默认1
        :params downsample: 默认False
        :params squeeze_factor: 默认4
        """
        super().__init__()
        squeeze_channels = out_channels // squeeze_factor
        # 01
        self.conv1 = nn.Conv2d(
            in_channels,
            squeeze_channels,
            1,
            bias=bias
        )
        self.bn1 = nn.BatchNorm2d(squeeze_channels)
        self.act1 = nn.ReLU()
        # 02
        self.conv2 = nn.Conv2d(
            squeeze_channels,
            squeeze_channels,
            3,
            stride=stride,
            padding=dilation,
            dilation=dilation,
            bias=bias
        )
        self.bn2 = nn.BatchNorm2d(squeeze_channels)
        self.act2 = nn.ReLU()
        # 03
        self.conv3 = nn.Conv2d(
            squeeze_channels,
            out_channels,
            1,
            bias=bias
        )
        self.bn3 = nn.BatchNorm2d(out_channels)
        self.act3 = nn.ReLU()
        # 11
        self.downsample = downsample
        if (in_channels != out_channels or stride != 1):
            self.downsample = True
        if self.downsample:
            self.conv_ = nn.Conv2d(
                in_channels,
                out_channels,
                1,
                stride=stride,
                bias=bias
            )
            self.bn_ = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        x0 = x
        x = self.act1(self.bn1(self.conv1(x)))
        x = self.act2(self.bn2(self.conv2(x)))
        x = self.bn3(self.conv3(x))
        if self.downsample:
            x0 = self.bn_(self.conv_(x0))
        return self.act3(x+x0)


# %% [markdown]
# ## ResNet18

# %%
class ResNet18(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ResNet18 from [ResNet]
    """

    def __init__(
        self,
        in_channels: int = 3,
        last_layer_use: bool = False,
        num_classes: int = 1000,
        bias: bool = False
    ):
        """
        :params in_channels: 默认3
        :params last_layer_use: 默认False
        :params num_classes: 默认1000
        :params bias: 默认False
        """
        super().__init__()
        self.num_classes = num_classes

        # 主干网络
        self.layer1 = nn.Sequential(
            Conv2d_BN2d_ReLU(in_channels, 64, 7, stride=2,
                             padding=3, bias=bias),
            nn.MaxPool2d(3, stride=2, padding=1)
        )
        self.layer2 = nn.Sequential(
            Basicblock(64, 64, bias=bias, stride=2),
            *[Basicblock(64, 64, bias=bias, stride=1) for _ in range(1)]

        )
        self.layer3 = nn.Sequential(
            Basicblock(64, 128, bias=bias, stride=2),
            *[Basicblock(128, 128, bias=bias, stride=1) for _ in range(1)]
        )
        self.layer4 = nn.Sequential(
            Basicblock(128, 256, bias=bias, stride=2),
            *[Basicblock(256, 256, bias=bias, stride=1) for _ in range(1)]
        )
        self.layer5 = nn.Sequential(
            Basicblock(256, 512, bias=bias, stride=2),
            *[Basicblock(512, 512, bias=bias, stride=1) for _ in range(1)]
        )
        self.last_layer_use = last_layer_use
        if last_layer_use:
            self.last_layer = nn.Sequential(
                nn.AdaptiveAvgPool2d((1, 1)),
                nn.Conv2d(512, num_classes, 1)
            )

    def forward(self, x):
        c1 = self.layer1(x)
        c2 = self.layer2(c1)
        c3 = self.layer3(c2)
        c4 = self.layer4(c3)
        c5 = self.layer5(c4)
        if self.last_layer_use:
            return self.last_layer(c5).reshape(x.shape[0], -1)
        else:
            return c5


# %% [markdown]
# ## ResNet34

# %%
class ResNet34(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ResNet34 from [ResNet]
    """

    def __init__(
        self,
        in_channels: int = 3,
        last_layer_use: bool = False,
        num_classes: int = 1000,
        bias: bool = False
    ):
        """
        :params in_channels: 默认3
        :params last_layer_use: 默认False
        :params num_classes: 默认1000
        :params bias: 默认False
        """
        super().__init__()
        self.num_classes = num_classes

        # 主干网络
        self.layer1 = nn.Sequential(
            Conv2d_BN2d_ReLU(in_channels, 64, 7, stride=2,
                             padding=3, bias=bias),
            nn.MaxPool2d(3, stride=2, padding=1)
        )
        self.layer2 = nn.Sequential(
            Basicblock(64, 64, bias=bias, stride=2),
            *[Basicblock(64, 64, bias=bias, stride=1) for _ in range(2)]
        )
        self.layer3 = nn.Sequential(
            Basicblock(64, 128, bias=bias, stride=2),
            *[Basicblock(128, 128, bias=bias, stride=1) for _ in range(3)]
        )
        self.layer4 = nn.Sequential(
            Basicblock(128, 256, bias=bias, stride=2),
            *[Basicblock(256, 256, bias=bias, stride=1) for _ in range(5)]
        )
        self.layer5 = nn.Sequential(
            Basicblock(256, 512, bias=bias, stride=2),
            *[Basicblock(512, 512, bias=bias, stride=1) for _ in range(2)]
        )
        self.last_layer_use = last_layer_use
        if last_layer_use:
            self.last_layer = nn.Sequential(
                nn.AdaptiveAvgPool2d((1, 1)),
                nn.Conv2d(512, num_classes, 1)
            )

    def forward(self, x):
        c1 = self.layer1(x)
        c2 = self.layer2(c1)
        c3 = self.layer3(c2)
        c4 = self.layer4(c3)
        c5 = self.layer5(c4)
        if self.last_layer_use:
            return self.last_layer(c5).reshape(x.shape[0], -1)
        else:
            return c5


# %% [markdown]
# ## ResNet50

# %%
class ResNet50(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ResNet50 from [ResNet]
    """

    def __init__(
        self,
        in_channels: int = 3,
        last_layer_use: bool = False,
        num_classes: int = 1000,
        bias: bool = False
    ):
        """
        :params in_channels: 默认3
        :params last_layer_use: 默认False
        :params num_classes: 默认1000
        :params bias: 默认False
        """
        super().__init__()
        self.num_classes = num_classes

        # 主干网络
        self.layer1 = nn.Sequential(
            Conv2d_BN2d_ReLU(in_channels, 64, 7, stride=2,
                             padding=3, bias=bias),
            nn.MaxPool2d(3, stride=2, padding=1)
        )
        self.layer2 = nn.Sequential(
            Bottleneck(64, 256, bias=bias, stride=2),
            *[Bottleneck(256, 256, bias=bias, stride=1) for _ in range(2)]
        )
        self.layer3 = nn.Sequential(
            Bottleneck(256, 512, bias=bias, stride=2),
            *[Bottleneck(512, 512, bias=bias, stride=1) for _ in range(3)]
        )
        self.layer4 = nn.Sequential(
            Bottleneck(512, 1024, bias=bias, stride=2),
            *[Bottleneck(1024, 1024, bias=bias, stride=1) for _ in range(5)]
        )
        self.layer5 = nn.Sequential(
            Bottleneck(1024, 2048, bias=bias, stride=2),
            *[Bottleneck(2048, 2048, bias=bias, stride=1) for _ in range(2)]
        )
        self.last_layer_use = last_layer_use
        if last_layer_use:
            self.last_layer = nn.Sequential(
                nn.AdaptiveAvgPool2d((1, 1)),
                nn.Conv2d(2048, num_classes, 1)
            )

    def forward(self, x):
        c1 = self.layer1(x)
        c2 = self.layer2(c1)
        c3 = self.layer3(c2)
        c4 = self.layer4(c3)
        c5 = self.layer5(c4)
        if self.last_layer_use:
            return self.last_layer(c5).reshape(x.shape[0], -1)
        else:
            return c5


# %% [markdown]
# ## ResNet101

# %%
class ResNet101(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ResNet101 from [ResNet]
    """

    def __init__(
        self,
        in_channels: int = 3,
        last_layer_use: bool = False,
        num_classes: int = 1000,
        bias: bool = False
    ):
        """
        :params in_channels: 默认3
        :params last_layer_use: 默认False
        :params num_classes: 默认1000
        :params bias: 默认False
        """
        super().__init__()
        self.num_classes = num_classes

        # 主干网络
        self.layer1 = nn.Sequential(
            Conv2d_BN2d_ReLU(in_channels, 64, 7, stride=2,
                             padding=3, bias=bias),
            nn.MaxPool2d(3, stride=2, padding=1)
        )
        self.layer2 = nn.Sequential(
            Bottleneck(64, 256, bias=bias, stride=2),
            *[Bottleneck(256, 256, bias=bias, stride=1) for _ in range(2)]
        )
        self.layer3 = nn.Sequential(
            Bottleneck(256, 512, bias=bias, stride=2),
            *[Bottleneck(512, 512, bias=bias, stride=1) for _ in range(3)]
        )
        self.layer4 = nn.Sequential(
            Bottleneck(512, 1024, bias=bias, stride=2),
            *[Bottleneck(1024, 1024, bias=bias, stride=1) for _ in range(22)]
        )
        self.layer5 = nn.Sequential(
            Bottleneck(1024, 2048, bias=bias, stride=2),
            *[Bottleneck(2048, 2048, bias=bias, stride=1) for _ in range(2)]
        )
        self.last_layer_use = last_layer_use
        if last_layer_use:
            self.last_layer = nn.Sequential(
                nn.AdaptiveAvgPool2d((1, 1)),
                nn.Conv2d(2048, num_classes, 1)
            )

    def forward(self, x):
        c1 = self.layer1(x)
        c2 = self.layer2(c1)
        c3 = self.layer3(c2)
        c4 = self.layer4(c3)
        c5 = self.layer5(c4)
        if self.last_layer_use:
            return self.last_layer(c5).reshape(x.shape[0], -1)
        else:
            return c5


# %% [markdown]
# ## ResNet152

# %%
class ResNet152(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ResNet152 from [ResNet]
    """

    def __init__(
        self,
        in_channels: int = 3,
        last_layer_use: bool = False,
        num_classes: int = 1000,
        bias: bool = False
    ):
        """
        :params in_channels: 默认3
        :params last_layer_use: 默认False
        :params num_classes: 默认1000
        :params bias: 默认False
        """
        super().__init__()
        self.num_classes = num_classes

        # 主干网络
        self.layer1 = nn.Sequential(
            Conv2d_BN2d_ReLU(in_channels, 64, 7, stride=2,
                             padding=3, bias=bias),
            nn.MaxPool2d(3, stride=2, padding=1)
        )
        self.layer2 = nn.Sequential(
            Bottleneck(64, 256, bias=bias, stride=2),
            *[Bottleneck(256, 256, bias=bias, stride=1) for _ in range(2)]
        )
        self.layer3 = nn.Sequential(
            Bottleneck(256, 512, bias=bias, stride=2),
            *[Bottleneck(512, 512, bias=bias, stride=1) for _ in range(7)]
        )
        self.layer4 = nn.Sequential(
            Bottleneck(512, 1024, bias=bias, stride=2),
            *[Bottleneck(1024, 1024, bias=bias, stride=1) for _ in range(35)]
        )
        self.layer5 = nn.Sequential(
            Bottleneck(1024, 2048, bias=bias, stride=2),
            *[Bottleneck(2048, 2048, bias=bias, stride=1) for _ in range(2)]
        )
        self.last_layer_use = last_layer_use
        if last_layer_use:
            self.last_layer = nn.Sequential(
                nn.AdaptiveAvgPool2d((1, 1)),
                nn.Conv2d(2048, num_classes, 1)
            )

    def forward(self, x):
        c1 = self.layer1(x)
        c2 = self.layer2(c1)
        c3 = self.layer3(c2)
        c4 = self.layer4(c3)
        c5 = self.layer5(c4)
        if self.last_layer_use:
            return self.last_layer(c5).reshape(x.shape[0], -1)
        else:
            return c5


# %% [markdown]
# # End

# %%



