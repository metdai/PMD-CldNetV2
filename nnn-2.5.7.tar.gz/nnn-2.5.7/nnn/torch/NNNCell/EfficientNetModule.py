# %% [markdown]
# # EfficientNetModule

# %%
import torch.nn as nn
import torch.nn.functional as F
from .DropPath import DropPath


# %% [markdown]
# ## SqueezeExcitation

# %%
class SqueezeExcitation(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    MBConv2d from [EfficientNet: Rethinking Model Scaling for Convolutional Neural Networks](https://arxiv.org/abs/1905.11946 "EfficientNetV1")
    """

    def __init__(
        self,
        in_channels: int,
        expand_channels: int,
        squeeze_factor: int = 4
    ):
        """
        :params in_channels: channel of input feature map of MBConv
        :params expand_channels: expand channel of MBConv
        :params squeeze_factor: 默认4
        """
        super().__init__()
        squeeze_channels = in_channels // squeeze_factor
        self.fc1 = nn.Conv2d(
            expand_channels,
            squeeze_channels,
            1
        )
        self.act1 = nn.SiLU()
        self.fc2 = nn.Conv2d(
            squeeze_channels,
            expand_channels,
            1
        )
        self.act2 = nn.Sigmoid()

    def forward(self, x):
        scale = F.adaptive_avg_pool2d(x, output_size=(1, 1))
        scale = self.fc1(scale)
        scale = self.act1(scale)
        scale = self.fc2(scale)
        scale = self.act2(scale)

        return scale*x


# %% [markdown]
# ## MBConv2d

# %%
class MBConv2d(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    MBConv2d from [EfficientNet: Rethinking Model Scaling for Convolutional Neural Networks](https://arxiv.org/abs/1905.11946 "EfficientNetV1")
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size=3,
        expand_factor=6,
        stride=1,
        squeeze_factor=None,
        p=0.2,
        dilation=1,
        bias=False,
        padding_mode='zeros'
    ):
        """
        :params in_channels: channel of input feature map of MBConv
        :params out_channels: output channel of MBConv
        :params kernel_size: 卷积核,默认3
        :params expand_factor: 膨胀因子,默认6
        :params stride: 默认1
        :params squeeze_factor: 收缩因子,默认None即不使用SqueezeExcitation模块
        :params p: 默认0.2
        :params dilation: 默认1
        :params bias: 默认False
        :params padding_mode: 'zeros'
        """
        super().__init__()
        if (stride == 1 and in_channels == out_channels):
            self.shortcut = True
            self.droppath = DropPath(p)
        else:
            self.shortcut = False

        self.expand_factor = expand_factor
        expand_channels = in_channels*expand_factor
        if self.expand_factor > 1:
            self.conv1 = nn.Sequential(
                nn.Conv2d(
                    in_channels,
                    expand_channels,
                    1
                ),
                nn.BatchNorm2d(expand_channels),
                nn.SiLU()
            )
        self.conv2 = nn.Sequential(
            nn.Conv2d(
                expand_channels,
                expand_channels,
                kernel_size,
                stride=stride,
                padding=int((kernel_size//2)*dilation),
                dilation=dilation,
                groups=expand_channels,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.BatchNorm2d(expand_channels),
            nn.SiLU()
        )
        self.squeeze_factor = squeeze_factor
        if self.squeeze_factor is not None:
            self.se = SqueezeExcitation(
                in_channels,
                expand_channels,
                self.squeeze_factor
            )
        self.conv3 = nn.Sequential(
            nn.Conv2d(
                expand_channels,
                out_channels,
                1
            ),
            nn.BatchNorm2d(out_channels)
        )

    def forward(self, x):
        x0 = x
        if self.expand_factor > 1:
            x = self.conv1(x)
        x = self.conv2(x)
        if self.squeeze_factor is not None:
            x = self.se(x)
        x = self.conv3(x)
        if self.shortcut:
            x = self.droppath(x)
            x = x+x0

        return x


# %% [markdown]
# ## FusedMBConv2d

# %%
class FusedMBConv2d(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    FusedMBConv2d from [EfficientNetV2: Smaller Models and Faster Training](https://arxiv.org/abs/2104.00298 "EfficientNetV2")
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size=3,
        expand_factor=4,
        stride=1,
        squeeze_factor=None,
        p=0.2,
        dilation=1,
        bias=False,
        padding_mode='zeros'
    ):
        """
        :params in_channels: channel of input feature map of MBConv
        :params out_channels: output channel of MBConv
        :params kernel_size: 卷积核,默认3
        :params expand_factor: 膨胀因子,默认4
        :params stride: 默认1
        :params squeeze_factor: 收缩因子,默认None即不使用SqueezeExcitation模块
        :params p: 默认0.2
        :params dilation: 默认1
        :params bias: 默认False
        :params padding_mode: 'zeros'
        """
        super().__init__()
        if (stride == 1 and in_channels == out_channels):
            self.shortcut = True
            self.droppath = DropPath(p)
        else:
            self.shortcut = False

        self.expand_factor = expand_factor
        expand_channels = in_channels*expand_factor
        self.conv2 = nn.Sequential(
            nn.Conv2d(
                in_channels,
                expand_channels if self.expand_factor > 1 else out_channels,
                kernel_size,
                stride=stride,
                padding=int((kernel_size//2)*dilation),
                dilation=dilation,
                groups=1,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.BatchNorm2d(expand_channels),
            nn.SiLU()
        )
        self.squeeze_factor = squeeze_factor
        if self.squeeze_factor is not None:
            self.se = SqueezeExcitation(
                in_channels,
                expand_channels if self.expand_factor > 1 else out_channels,
                self.squeeze_factor
            )
        if self.expand_factor > 1:
            self.conv3 = nn.Sequential(
                nn.Conv2d(
                    expand_channels,
                    out_channels,
                    1
                ),
                nn.BatchNorm2d(out_channels)
            )

    def forward(self, x):
        x0 = x
        x = self.conv2(x)
        if self.squeeze_factor is not None:
            x = self.se(x)
        if self.expand_factor > 1:
            x = self.conv3(x)
        if self.shortcut:
            x = self.droppath(x)
            x = x+x0

        return x



