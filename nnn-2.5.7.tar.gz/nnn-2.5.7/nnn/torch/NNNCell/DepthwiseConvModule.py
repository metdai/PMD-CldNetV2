# %% [markdown]
# # DepthwiseConvModule

# %%
import torch.nn as nn


# %% [markdown]
# ## DepthwiseConv2d

# %%
class DepthwiseConv2d(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    DepthwiseConv2d
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size=3,
        stride=1,
        padding=0,
        dilation=1,
        bias=True,
        padding_mode='zeros'
    ):
        super().__init__()
        self.DepthwiseConv2d = nn.Sequential(
            nn.Conv2d(
                in_channels,
                in_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                groups=in_channels,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.Conv2d(
                in_channels,
                out_channels,
                1,
                bias=bias
            )
        )

    def forward(self, x):
        return self.DepthwiseConv2d(x)


# %% [markdown]
# ## DepthwiseConv2d_ReLU

# %%
class DepthwiseConv2d_ReLU(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    DepthwiseConv2d_ReLU
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size=3,
        stride=1,
        padding=0,
        dilation=1,
        bias=True,
        padding_mode='zeros'
    ):
        super().__init__()
        self.DepthwiseConv2d_ReLU = nn.Sequential(
            DepthwiseConv2d(
                in_channels,
                out_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.ReLU()
        )

    def forward(self, x):
        return self.DepthwiseConv2d_ReLU(x)


# %% [markdown]
# ## DepthwiseConv2d_ReLU_BN2d

# %%
class DepthwiseConv2d_ReLU_BN2d(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    DepthwiseConv2d_ReLU_BN2d
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size=3,
        stride=1,
        padding=0,
        dilation=1,
        bias=True,
        padding_mode='zeros'
    ):
        super().__init__()
        self.DepthwiseConv2d_ReLU_BN2d = nn.Sequential(
            DepthwiseConv2d(
                in_channels,
                out_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.ReLU(),
            nn.BatchNorm2d(out_channels)
        )

    def forward(self, x):
        return self.DepthwiseConv2d_ReLU_BN2d(x)


# %% [markdown]
# ## DepthwiseConv2d_BN2d

# %%
class DepthwiseConv2d_BN2d(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    DepthwiseConv2d_BN2d
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size=3,
        stride=1,
        padding=0,
        dilation=1,
        bias=True,
        padding_mode='zeros'
    ):
        super().__init__()
        self.DepthwiseConv2d_BN2d = nn.Sequential(
            DepthwiseConv2d(
                in_channels,
                out_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.BatchNorm2d(out_channels)
        )

    def forward(self, x):
        return self.DepthwiseConv2d_BN2d(x)


# %% [markdown]
# ## DepthwiseConv2d_BN2d_ReLU

# %%
class DepthwiseConv2d_BN2d_ReLU(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    DepthwiseConv2d_BN2d_ReLU
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        in_channels,
        out_channels,
        kernel_size=3,
        stride=1,
        padding=0,
        dilation=1,
        bias=True,
        padding_mode='zeros'
    ):
        super().__init__()
        self.DepthwiseConv2d_BN2d_ReLU = nn.Sequential(
            DepthwiseConv2d(
                in_channels,
                out_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                bias=bias,
                padding_mode=padding_mode
            ),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        )

    def forward(self, x):
        return self.DepthwiseConv2d_BN2d_ReLU(x)



