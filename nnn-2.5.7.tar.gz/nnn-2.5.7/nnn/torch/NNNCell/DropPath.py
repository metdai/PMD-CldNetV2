# %%
import torch
import torch.nn as nn
import torch.nn.functional as F

class DropPath(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    DropPath: 多分支的Dropout
    B, N, D, ... 沿着B这个分支维度进行丢弃
    @author: BEOH
    @email: beoh86@yeah.net
    """

    def __init__(
        self,
        p=0.5
    ):
        super().__init__()
        self.p = p

    def forward(self, x):
        if self.p > 0.0 and self.training:
            keep_p = 1.0 - self.p
            shape = (x.shape[0],) + (1,) * (x.ndim-1)
            random_keep = keep_p + \
                torch.rand(shape, dtype=x.dtype, device=x.device)
            # > 1.0 = 1.0   < 1.0 = 0.0
            random_mask = random_keep.floor()
            x = x.div(keep_p) * random_mask
            return x
        return x



