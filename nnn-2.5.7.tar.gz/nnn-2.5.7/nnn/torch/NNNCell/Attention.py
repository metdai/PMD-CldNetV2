# %% [markdown]
# # 自注意力机制(Attention)

# %%
import torch.nn as nn
import torch


# %% [markdown]
# ## Attention1d

# %%
"""
Created on Tue. November 22 10:33:28 2022
Attention1d
@author: BEOH
@email: beoh86@yeah.net
"""


class Attention1d(nn.Module):
    """参数:
        Attention1d
        - in_size: int
            输入通道数
        - qk_size: int
            qk通道数
        - out_size: int
            输出通道数
        - bias: bool
            是否添加偏置\n
        example:
        - inputs: (N, L, in_size)
        - outputs: (N, L, out_size)
    """

    def __init__(self,
                 in_size,
                 qk_size,
                 out_size,
                 bias=True):
        super().__init__()
        self.in_size = in_size
        self.qk_size = qk_size
        self.out_size = out_size
        self.bias = bias
        self.q_proj = nn.Linear(self.in_size, self.qk_size, bias=self.bias)
        self.k_proj = nn.Linear(self.in_size, self.qk_size, bias=self.bias)
        self.v_proj = nn.Linear(self.in_size, self.out_size, bias=self.bias)
        self.softmax = nn.Softmax(dim=-1)
        self.norm_factor = 1.0/(self.qk_size**0.5)

    def forward(self, inputs):
        Q = self.q_proj(inputs)
        K = self.k_proj(inputs)
        V = self.v_proj(inputs)

        QK = torch.bmm(Q, K.permute(0, 2, 1))*self.norm_factor
        QK = self.softmax(QK)
        outputs = torch.bmm(QK, V)

        return outputs


# %% [markdown]
# ## Attention2d

# %%
"""
Created on Tue. November 22 10:33:28 2022
Attention2d
@author: BEOH
@email: beoh86@yeah.net
"""


class Attention2d(nn.Module):
    """参数:
        Attention2d
        - in_size: int
            输入通道数
        - out_size: int
            输出通道数
        - kernel_size: int or (int, int)
            卷积核大小
        - bias: bool
            是否添加偏置
        - padding: (int, int)
            None:根据卷积核计算得到\n
        example:
        - inputs: (N, in_size, H, W)
        - outputs: (N, out_size, H, W)
    """

    def __init__(self,
                 in_size,
                 out_size,
                 kernel_size,
                 bias=True,
                 padding=None):
        super().__init__()
        self.in_size = in_size
        self.out_size = out_size
        self.kernel_size = kernel_size
        self.bias = bias
        if padding is None:
            self.padding = kernel_size//2 if isinstance(
                kernel_size, int) else (kernel_size[0]//2, kernel_size[1]//2)
        else:
            self.padding = padding
        self.qkv_conv2d = nn.Conv2d(self.in_size,
                                    3*self.out_size,
                                    self.kernel_size,
                                    padding=self.padding,
                                    bias=self.bias)
        self.softmax = nn.Softmax(dim=-1)
        self.norm_factor = 1.0/(self.out_size**0.5)

    def forward(self, inputs):
        QKV = self.qkv_conv2d(inputs)
        Q, K, V = torch.chunk(QKV, 3, dim=-3)
        bs, c, h, w = K.shape
        Q = Q.reshape(-1, h, w)
        K = K.reshape(-1, h, w).permute(0, 2, 1)
        V = V.reshape(-1, h, w)
        QK = torch.bmm(Q, K)*self.norm_factor
        QK = QK.reshape(-1, h*h)
        QK = self.softmax(QK)
        QK = QK.reshape(-1, h, h)
        outputs = torch.bmm(QK, V)

        return outputs.reshape(bs, c, h, w)


# %% [markdown]
# ## End

# %%



