# %% [markdown]
# # DeepLabModule

# %%
import torch
import torch.nn as nn
import torch.nn.functional as F
from .DepthwiseConvModule import DepthwiseConv2d


# %% [markdown]
# ## ASPP

# %%
class ASPP(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    ASPP (Atrous Spatial Pyramid Pooling) from [DeepLab: Semantic Image Segmentation with Deep Convolutional Nets, Atrous Convolution, and Fully Connected CRFs]
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        dilations=None,
        bias=True,
        stride=1,
        is_bn: bool=True,
        is_act: bool=True,
        bias2=True,
        stride2=1,
        is_bn2: bool=True,
        is_act2: bool=True
    ):
        """
        :params in_channels
        :params out_channels
        :params dilations: 默认None,即[1, 6, 12, 18]
        :params bias: 默认True
        :params stride: 默认1
        :params is_bn: 默认True
        :params is_act: 默认True
        :params bias2: 默认True
        :params stride2: 默认1
        :params is_bn2: 默认True
        :params is_act2: 默认True
        """
        super().__init__()
        if dilations is None:
            dilations = [1, 6, 12, 18]
        if len(dilations) < 1:
            raise ValueError('dilations is null')

        netlist = []
        for dilation in dilations:
            netlist.append(
                nn.Sequential(
                    nn.Conv2d(
                        in_channels,
                        out_channels,
                        3,
                        bias=bias,
                        stride=stride,
                        padding=dilation,
                        dilation=dilation
                    ),
                    nn.BatchNorm2d(out_channels) if is_bn else nn.Identity(),
                    nn.ReLU() if is_act else nn.Identity()
                )
            )
        self.netlist = nn.ModuleList(netlist)
        self.aapool2d = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Conv2d(
                in_channels,
                out_channels,
                1,
                bias=bias,
                stride=1,
                padding=0,
                dilation=1
            ),
            nn.BatchNorm2d(out_channels) if is_bn else nn.Identity(),
            nn.ReLU() if is_act else nn.Identity()
        )

        self.conv2d = nn.Sequential(
            nn.Conv2d(
                out_channels*int(len(dilations)+1),
                out_channels,
                1,
                bias=bias2,
                stride=stride2,
                padding=0,
                dilation=1
            ),
            nn.BatchNorm2d(out_channels) if is_bn2 else nn.Identity(),
            nn.ReLU() if is_act2 else nn.Identity()
        )

    def forward(self, x):
        xx = []
        for cc in self.netlist:
            xx.append(cc(x))
        xx.append(F.interpolate(self.aapool2d(x),
                  size=xx[0].shape[-2:], mode='bilinear'))
        xx = torch.cat(xx, dim=1)
        xx = self.conv2d(xx)

        return xx


# %% [markdown]
# ## DepthwiseASPP

# %%
class DepthwiseASPP(nn.Module):
    """
    Created on Sat January 01 15:39:20 2022
    DepthwiseASPP
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        dilations=None,
        bias=True,
        stride=1,
        is_bn: bool=True,
        is_act: bool=True,
        bias2=True,
        stride2=1,
        is_bn2: bool=True,
        is_act2: bool=True
    ):
        """
        :params in_channels
        :params out_channels
        :params dilations: 默认None,即[1, 6, 12, 18]
        :params bias: 默认True
        :params stride: 默认1
        :params is_bn: 默认True
        :params is_act: 默认True
        :params bias2: 默认True
        :params stride2: 默认1
        :params is_bn2: 默认True
        :params is_act2: 默认True
        """
        super().__init__()
        if dilations is None:
            dilations = [1, 6, 12, 18]
        if len(dilations) < 1:
            raise ValueError('dilations is null')

        netlist = []
        for dilation in dilations:
            netlist.append(
                nn.Sequential(
                    DepthwiseConv2d(
                        in_channels,
                        out_channels,
                        3,
                        bias=bias,
                        stride=stride,
                        padding=dilation,
                        dilation=dilation
                    ),
                    nn.BatchNorm2d(out_channels) if is_bn else nn.Identity(),
                    nn.ReLU() if is_act else nn.Identity()
                )
            )
        self.netlist = nn.ModuleList(netlist)
        self.aapool2d = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            DepthwiseConv2d(
                in_channels,
                out_channels,
                1,
                bias=bias,
                stride=1,
                padding=0,
                dilation=1
            ),
            nn.BatchNorm2d(out_channels) if is_bn else nn.Identity(),
            nn.ReLU() if is_act else nn.Identity()
        )

        self.conv2d = nn.Sequential(
            DepthwiseConv2d(
                out_channels*int(len(dilations)+1),
                out_channels,
                1,
                bias=bias2,
                stride=stride2,
                padding=0,
                dilation=1
            ),
            nn.BatchNorm2d(out_channels) if is_bn2 else nn.Identity(),
            nn.ReLU() if is_act2 else nn.Identity()
        )

    def forward(self, x):
        xx = []
        for cc in self.netlist:
            xx.append(cc(x))
        xx.append(
            F.interpolate(
                self.aapool2d(x),
                size=xx[0].shape[-2:],
                mode='bilinear'
            )
        )
        xx = torch.cat(xx, dim=1)
        xx = self.conv2d(xx)

        return xx



