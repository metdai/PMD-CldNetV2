# nnn

## 介绍
nnn: n neural network
To be stronger, to be ...

## 安装
> git clone 此仓库地址
> 
> cd ./nnn

```cmd
python setup.py build
python setup.py sdist
pip install ./dist/.tar.gz
```

## git常用命令
- 推送代码
```cmd
git add .
git commit -m "xxxxxx"
git push
```
- 给代码打标记
```cmd
git tag v2.1.202304221500
git tag v2.1.6 v2.1.202304221500
git push origin v2.1.6
```
