import os
from setuptools import setup, find_packages

path = os.path.abspath(os.path.dirname(__file__))

try:
    with open(os.path.join(path, 'README.md')) as f:
        long_description = f.read()
except Exception as e:
    long_description = "customize nnn"

setup(
    name="nnn",
    version="2.5.7",
    keywords=["NNN", "PNN", "NNNCell", "FLOW", "pytorch", "paddlepaddle"],
    description="N Neural Network",
    long_description=long_description,
    long_description_content_type='text/markdown',
    python_requires=">=3.6.0",
    license="MIT Licence",

    url="#",
    author="nielongfeng",
    author_email="nielongfeng@outlook.com",

    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    platforms="any",

    scripts=[],
    entry_points={
        'console_scripts': [

        ]
    }
)


# from setuptools import setup
# setup(name='nnn'
#     , version='0.1'
#     , description='N Neural Network'
#     , url='#'
#     , author='BEOH'
#     , author_email='BEOH@email.com'
#     , license='MIT'
#     , packages=['nnn']
#     , zip_safe=False
#     )
